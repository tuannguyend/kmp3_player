
/*
 * CANMotorola.c
 *
 *  Created on: Nov 28, 2014
 *      Author: nvthanh
 */


//#include "CANMotorola.h"
//#include <common/Debug.h>
#include <stdio.h>
#include <string.h>
#include <endian.h>
#include <stdint.h>
#include <stdbool.h>

uint8_t reverse_mask[] =
   {0x7f,0x33,0x70,0x7f};
//static const uint8_t reverse_mask_xor[] =
//    { 0xff, 0x7f, 0x3f, 0x1f, 0x0f, 0x07, 0x03, 0x01, 0x00 };
uint8_t testset[8];
typedef struct bitnumber{
  	unsigned char b0  : 1;
	unsigned char b1  : 1;
	unsigned char b2  : 1;
	unsigned char b3  : 1;
 	unsigned char b4  : 1;
	unsigned char b5  : 1;
 	unsigned char b6  : 1;
	unsigned char b7  : 1;
 	//unsigned char b7  : 1;
	//int type; // big, little
} bitnumber;
typedef union byteArray{
  uint64_t v64;
	unsigned char byte;
	bitnumber bit;
  unsigned char bytes[8];
}byteArray;
#define CHAR_BIT 8
static uint64_t get_bitfield(const uint8_t source[], const uint8_t source_length,
                const uint16_t offset, const uint16_t bit_count)
{
	byteArray value;
	int i=0;
	uint16_t source_length_bits = source_length * CHAR_BIT;
	uint16_t new_offset = offset + (64 - source_length_bits);
//	DBG("\n");
	if(source_length > 8 || source_length_bits < (int)((int)offset/8 +1)*8) return 0;
	memset(value.bytes,0,sizeof(byteArray));
	memcpy(value.bytes+(8 - source_length),source,source_length);
	for (i=0;i<8;i++) printf("0x%X ", (int)value.bytes[i]);
	printf("\n");
	if(BYTE_ORDER == LITTLE_ENDIAN)
	{
		value.v64 = __builtin_bswap64(value.v64);
	}
	for (i=0;i<8;i++) printf("0x%X ", (int)value.bytes[i]);
	printf("\n");
	if( ((int)((int)new_offset/8 +1)*8 - ((int)bit_count + (int)( (int)new_offset%8))) < 0){
		printf("not enough bits\n");
		return 0;
	}

//	value.v64 = value.v64 << (new_offset  - bit_count + (8-new_offset%8));
//	value.v64 = value.v64 >> (new_offset  - bit_count + (8-new_offset%8));
// 	value.v64 = value.v64 >> (64 - (new_offset)   - (8-new_offset%8));
	uint16_t shift_left, shift_right;
	shift_left = ((new_offset/8 +1)*8  - (bit_count + (new_offset%8)));
	shift_right =  64 - shift_left - bit_count;
	value.v64 = value.v64 << shift_left;
	printf("<< %d\n",shift_left);
	for (i=0;i<8;i++) printf("0x%X ", (int)value.bytes[i]);
	printf("\n");

	value.v64 = value.v64 >> shift_left;
	for (i=0;i<8;i++) printf("0x%X ", (int)value.bytes[i]);
	printf("\n");
	value.v64 = value.v64 >> shift_right;
	printf(">> %d\n",shift_right);
	for (i=0;i<8;i++) printf("0x%X ", (int)value.bytes[i]);
	printf("\n");
//	DBG("\n");
	printf("bit number: b0: %x b1: %x b2: %x b3: %xb4: %x b5: %xb6: %x b7: %x  \n",value.bit.b0,value.bit.b1,value.bit.b2,value.bit.b3,value.bit.b4,value.bit.b5,value.bit.b6,value.bit.b7);
	return value.v64;
}
static bool set_bitfield(const uint64_t in_value, const uint16_t offset,
        const uint16_t bit_count, uint8_t destination[],
        uint16_t destination_length)
{
	bool ret=true;
	byteArray value;
	byteArray value_new ;
	int i=0;
	value_new.v64  = in_value;
for (i=0;i<8;i++) printf("0x%X ", (int)value_new.bytes[i]);
	printf("\n");

	uint16_t destination_length_bits = destination_length * CHAR_BIT;
	uint16_t new_offset = offset + (64 - destination_length_bits);
//	uint16_t shift_left, shift_right, left_pos, right_pos;
	if(destination_length > 8) return false;
	if(bit_count > destination_length_bits) return false;
	if((int ) 64 - (int)(new_offset/8 +1)*8  +  (int)(new_offset%8) < 0) return false;
	value_new.v64 <<= 64 - bit_count;
	for (i=0;i<8;i++) printf("0x%X ", (int)value_new.bytes[i]);
	printf("\n");
	value_new.v64 >>= 64 - bit_count;
	for (i=0;i<8;i++) printf("0x%X ", (int)value_new.bytes[i]);
	printf("\n");
	value_new.v64 <<= 64 - (new_offset/8 +1)*8  +  ( new_offset%8);
printf("<< %d ",(64- (new_offset/8 +1)*8  +  ( new_offset%8)));	
	for (i=0;i<8;i++) printf("0x%X ", (int)value_new.bytes[i]);
	printf("\n");
	memset(value.bytes,0,sizeof(byteArray));
	memcpy(value.bytes+(8 - destination_length),destination,destination_length);
	if(BYTE_ORDER == LITTLE_ENDIAN)
	{
		value.v64 = __builtin_bswap64(value.v64);
	}
	value.v64 |= value_new.v64;
	if(BYTE_ORDER == LITTLE_ENDIAN)
	{
		value.v64 = __builtin_bswap64(value.v64);
	}
	for (i=0;i<8;i++) printf("0x%X ", (int)value.bytes[i]);
	printf("\n");
	memcpy(destination,value.bytes+(8 - destination_length),destination_length);

	return ret;
}

int main()
{
	float x,y,g;
	byteArray value1;
	int i=0;
	printf("\n");
	value1.v64 = get_bitfield(reverse_mask,2,8,16);
	
	set_bitfield(value1.v64,0,5,testset,1);
	
	for (i=0;i<8;i++)
	{
		printf("\nvalue of testset: %x \n",testset[i]);
	}
	get_bitfield(testset,1,0,8);
	return 0;
}
 
