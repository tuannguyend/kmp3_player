/*
	Format CANMotorola_Forward LSB
*/

#include <stdio.h>
#include <string.h>
#include <endian.h>
#include <stdint.h>
#include <stdbool.h>
uint8_t reverse_mask[] = {0x7f,0x33,0x70,0x7f};

typedef union byteArray{
  uint64_t v64;
  unsigned char bytes[8];
}byteArray;
#define CHAR_BIT 8
static uint64_t get_bitfield(const uint8_t source[], const uint8_t source_length,
                const uint16_t offset, const uint16_t bit_count)
{
	int i=0;
printf("<< %d\n",( offset%8));
	byteArray value;
	uint16_t source_length_bits = source_length * CHAR_BIT;
	uint16_t new_offset = offset + (64 - source_length_bits);
//	DBG("\n");
	if(source_length > 8 || source_length_bits < (int)((int)offset/8 +1)*8) return 0;
	memset(value.bytes,0,sizeof(byteArray));
	memcpy(value.bytes+(8 - source_length),source,source_length);
	for (i=0;i<8;i++) printf("0x%X ", (int)value.bytes[i]);
	printf("\n");

	uint16_t shift_left, shift_right;
	shift_left = (64 - source_length_bits) + ( new_offset%8);
	shift_right =  64 - shift_left - bit_count;
	if(  (64 - shift_left - bit_count) < 0){
		printf("not enough bits\n");
		return 0;
	}

	value.v64 = value.v64 >> shift_left;
	printf("<< %d\n",shift_left);
	printf("<< %d\n",( shift_right));
	for (i=0;i<8;i++) printf("0x%X ", (int)value.bytes[i]);
	printf("\n");

	value.v64 = value.v64 << shift_left;
	for (i=0;i<8;i++) printf("0x%X ", (int)value.bytes[i]);
	printf("\n");
	value.v64 = value.v64 << shift_right;
	for (i=0;i<8;i++) printf("0x%X ", (int)value.bytes[i]);
	printf("\n");
	if(BYTE_ORDER == LITTLE_ENDIAN)
	{
		value.v64 = __builtin_bswap64(value.v64);
	}
//	printf(">> %d\n",shift_right);
	for (i=0;i<8;i++) printf("0x%X ", (int)value.bytes[i]);
	printf("\n");
//	DBG("\n");
	return value.v64;
}

static bool set_bitfield(const uint64_t in_value, const uint16_t offset,
        const uint16_t bit_count, uint8_t destination[],
        uint16_t destination_length)
{
	bool ret=true;
	byteArray value;
	byteArray value_new ;
	value_new.v64  = in_value;
//	int i=0;
	uint16_t destination_length_bits = destination_length * CHAR_BIT;
	uint16_t new_offset = offset + (64 - destination_length_bits);
//	uint16_t shift_left, shift_right, left_pos, right_pos;
	if(destination_length > 8) return false;
	if(bit_count > destination_length_bits) return false;
	if((int ) 64 - (int)(new_offset/8 +1)*8  +  (int)(new_offset%8) < 0) return false;
	value_new.v64 <<= 64 - bit_count;
	value_new.v64 >>= 64 - bit_count;
	value_new.v64 <<= 64 - (new_offset/8 +1)*8  +  ( new_offset%8);
	memset(value.bytes,0,sizeof(byteArray));
	memcpy(value.bytes+(8 - destination_length),destination,destination_length);
	if(BYTE_ORDER == LITTLE_ENDIAN)
	{
		value.v64 = __builtin_bswap64(value.v64);
	}
	value.v64 |= value_new.v64;
	if(BYTE_ORDER == LITTLE_ENDIAN)
	{
		value.v64 = __builtin_bswap64(value.v64);
	}
	memcpy(destination,value.bytes+(8 - destination_length),destination_length);
	return ret;
}

int main()
{
	byteArray value;
	int i=0;
	printf("\n");
	get_bitfield(reverse_mask,2,9,16);

	//set_bitfield(value.v64,18,16,testset,4);
	
	//for (i=0;i<2;i++)
	//{
	//	printf("\nvalue of testset: %x \n",testset[i]);
	//}
	//get_bitfield(testset,4,18,16);
	return 0;
}


