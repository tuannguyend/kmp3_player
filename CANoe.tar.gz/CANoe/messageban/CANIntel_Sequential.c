/*
	format Intel_Sequential
*/

#include <stdio.h>
#include <string.h>
#include <endian.h>
#include <stdint.h>
#include <stdbool.h>

uint8_t reverse_mask[] =
   {0x7f,0x3f,0x44};

uint8_t testset[8];

typedef union byteArray{
  uint64_t v64;
  unsigned char bytes[8];
}byteArray;
void swap (uint8_t *x)
{
	uint8_t *temp =x;
	*temp = ((*temp >>7) | ((*temp >>5)&0x2) | ((*temp >>3)&0x4) | ((*temp >> 1)&0x8) | ((*temp << 7)&0x80) | ((*temp << 5)&0x40) | ((*temp << 3)&0x20) | ((*temp << 1)&0x10));
}
#define CHAR_BIT 8
static uint64_t get_bitfield(const uint8_t source[], const uint8_t source_length,
                const uint16_t offset, const uint16_t bit_count)
{
	byteArray value;
	uint8_t tempsource[8];
	int i=0;
	uint16_t source_length_bits = source_length * CHAR_BIT;

	if(source_length > 8 || source_length_bits < (int)((int)offset/8 +1)*8) return 0;
	for (i=0;i<source_length;i++)
	{
		tempsource[i] = source[i];
		swap(&tempsource[i]);
	}
	memset(value.bytes,0,sizeof(byteArray));
	memcpy(value.bytes,tempsource,source_length);	
	
	for (i=0;i<8;i++) printf("0x%X ", (int)value.bytes[i]);
	printf("\n");
	
	uint16_t shift_left, shift_right;
	shift_left = 64  + (source_length_bits - bit_count - offset) - source_length_bits;
	shift_right = offset ;
	value.v64 = value.v64 >> offset;
	value.v64 = value.v64 << offset;
	value.v64 = value.v64 << shift_left;
	printf("<< %d\n",shift_left);
	for (i=0;i<8;i++) printf("0x%X ", (int)value.bytes[i]);
	printf("\n");

	value.v64 = value.v64 >> shift_left;
	for (i=0;i<8;i++) printf("0x%X ", (int)value.bytes[i]);
	printf("\n");

	printf(">> %d\n",shift_right);
	for (i=0;i<8;i++) printf("0x%X ", (int)value.bytes[i]);
	printf("\n");

//	DBG("\n");
	return value.v64;
}
static bool set_bitfield(const uint64_t in_value, const uint16_t offset,
        const uint16_t bit_count, uint8_t destination[],
        uint16_t destination_length)
{
	bool ret=true;
	int i=0;
	byteArray value;
	byteArray value_new ;
	value_new.v64  = in_value;	
	printf("\ndang hex: ");
	for (i=0;i<8;i++) printf("0x%X ", (int)value_new.bytes[i]);
	printf("\n");
	uint16_t destination_length_bits = destination_length * CHAR_BIT;	

	if(destination_length > 8) return false;
	if(bit_count > destination_length_bits){printf("\nfalse"); return false;}
	//if((int ) 64 - (int)(new_offset/8 +1)*8  +  (int)(new_offset%8) < 0) return false;
	value_new.v64 <<= 64  + (destination_length_bits - bit_count) - destination_length_bits;
	for (i=0;i<8;i++) printf("0x%X ", (int)value_new.bytes[i]);
	printf("\n done <<=\n");
	value_new.v64 >>= 64 + (destination_length_bits - bit_count) - destination_length_bits;	
	for (i=0;i<8;i++) printf("0x%X ", (int)value_new.bytes[i]);
	printf("\ndone =>>\n");
	value_new.v64 <<= offset;
	memset(value.bytes,0,sizeof(byteArray));
	memcpy(value.bytes+(8 - destination_length),destination,destination_length);
	value.v64 |= value_new.v64;
	
	memcpy(destination,value.bytes,destination_length);
	for(i =0; i< destination_length;i++)
	{
		swap(&destination[i]);
	}
	for (i=0;i<8;i++) printf("0x%X ", (int)destination[i]);
	
	
	return ret;
}

int main()
{
	byteArray value;
	int i=0;
	printf("\n");
	value.v64 = get_bitfield(reverse_mask,2,0,16);
	
	set_bitfield(value.v64,0,16,testset,2);
	
	for (i=0;i<2;i++)
	{
		printf("\nvalue of testset: %x \n",testset[i]);
	}
	get_bitfield(testset,1,1,8);
	return 0;
}
