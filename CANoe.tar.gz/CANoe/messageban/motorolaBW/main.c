/*
 *CANMotorola_ForWard_MSB
 */

#include <stdio.h>
#include <string.h>
#include <endian.h>
#include <stdint.h>
#include <stdbool.h>

static const uint8_t reverse_mask[] =
   { 0x7f, 0x55, 0xc0,0xff,0xfe};
uint8_t testset[8];
typedef union byteArray{
  uint64_t v64;
  unsigned char bytes[8];
}byteArray;
#define CHAR_BIT 8
static uint64_t get_bitfield(const uint8_t source[], const uint8_t source_length,
                const uint16_t offset, const uint16_t bit_count)
{
    byteArray value;
    int i=0;
    uint16_t source_length_bits = source_length * CHAR_BIT;


    if(source_length > 8 || source_length_bits < (int)((int)offset/8 +1)*8) return 0;
    memset(value.bytes,0,sizeof(byteArray));
    memcpy(value.bytes+(8 - source_length),source,source_length);

    if(BYTE_ORDER == LITTLE_ENDIAN)
    {
        value.v64 = __builtin_bswap64(value.v64);
    }
    value.v64 >>= (offset%8);
    value.v64 <<= (offset%8);
    value.v64 <<= (64 - source_length_bits + (source_length_bits -bit_count - (offset%8)));
    value.v64 >>= (64 - source_length_bits + (source_length_bits -bit_count - (offset%8)));

    for (i=0;i<8;i++) printf("0x%X ", (int)value.bytes[i]);
    printf("\n");

    return value.v64;
}

static bool set_bitfield(const uint64_t in_value, const uint16_t offset,
        const uint16_t bit_count, uint8_t destination[],
        uint16_t destination_length)
{
    bool ret=true;
    byteArray value;
    byteArray value_new ;
    value_new.v64  = in_value;
    int i=0;
    uint16_t destination_length_bits = destination_length * CHAR_BIT;

    if(destination_length > 8) return false;
    if(bit_count > destination_length_bits) return false;
    //if((int ) 64 - (int)(new_offset/8 +1)*8  +  (int)(new_offset%8) < 0) return false;
    value_new.v64 <<= (offset%8);
    value_new.v64 <<= (64 - destination_length_bits + (destination_length_bits -bit_count - (offset%8)));
    value_new.v64 >>= (64 - destination_length_bits + (destination_length_bits -bit_count - (offset%8)));
    memset(value.bytes,0,sizeof(byteArray));
    memcpy(value.bytes+(8 - destination_length),destination,destination_length);
    if(BYTE_ORDER == LITTLE_ENDIAN)
    {
        value.v64 = __builtin_bswap64(value.v64);
    }
    value.v64 |= value_new.v64;
    if(BYTE_ORDER == LITTLE_ENDIAN)
    {
        value.v64 = __builtin_bswap64(value.v64);
    }
    memcpy(destination,value.bytes+(8 - destination_length),destination_length);
    for (i=0;i<8;i++) printf("0x%X ", (int)destination[i]);
    printf("\n");
    return ret;
}
int main()
{
    byteArray value1;
    value1.v64 = get_bitfield(reverse_mask,4,10,30);
    set_bitfield(value1.v64,18,17,testset,4);
    get_bitfield(testset,4,20,5);
    return 0;
}
