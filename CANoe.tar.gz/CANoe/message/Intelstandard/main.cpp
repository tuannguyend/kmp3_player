
#include <stdio.h>
#include "intelstandard.c"

#include <stdbool.h>

int main()
{
      //  float x,y,g;
        byteArray value1;
        int i=0;
        printf("\n");
        value1.v64 = get_bitfield(reverse_mask,2,0,16);

      //  printf("Check GET:", value1.v64);


        set_bitfield(value1.v64,4,10,testset,2);
        for (i=0;i<sizeof(testset);i++)
        {
            printf("\nvalue of testset: %x ",testset[i]);
        }
          get_bitfield(testset,2,2,10);
        return 0;

}
