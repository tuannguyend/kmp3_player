
#include <stdio.h>
#include "motorolaBW.c"

#include <stdbool.h>

int main()
{
      byteArray value1;
      value1.v64 = get_bitfield(reverse_mask,4,10,30);
      set_bitfield(value1.v64,18,17,testset,4);
      get_bitfield(testset,4,20,5);
      return 0;
}

