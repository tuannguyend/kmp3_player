#ifndef HARDWAREINTERFACE_H
#define HARDWAREINTERFACE_H

#include <QDialog>

namespace Ui {
class HardwareInterface;
}

class HardwareInterface : public QDialog
{
    Q_OBJECT

public:
    explicit HardwareInterface(QWidget *parent = 0);
    ~HardwareInterface();
protected:
    void closeEvent(QCloseEvent *event);
private slots:
    void on_ButtonCAN1_clicked();
    void on_ButtonCAN2_clicked();
    void on_buttonOk_accept();
    void on_buttonCancel_reject();
    void on_buttonHelp_click();

private:
    Ui::HardwareInterface *ui;
};

#endif // HARDWAREINTERFACE_H
