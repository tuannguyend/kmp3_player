#include "filtermanager.h"
#include "ui_filtermanager.h"
#include "filterdialoggetid.h"
#include <QTableWidget>
#include <QDialog>
#include <QMessageBox>
#include <QDebug>
#include <QComboBox>
#include <QSize>
#include <QLabel>
#include <QHeaderView>
FilterManagerWindow::FilterManagerWindow(QWidget *parent) :
    QMainWindow(parent)
{

    setupUi(this);   
    //Set table row count 6 and column count 6
    m_HeaderView =  new QHeaderView(Qt::Horizontal);
    tableWidget->setRowCount(1);
    tableWidget->setColumnCount(6);
    tableWidget->setSizePolicy(QSizePolicy::Expanding,QSizePolicy::Expanding);

    //Set Header Label Texts Here
    m1_TableHeader<<"Identifier"<<"Type"<<"Channel"<<"Rx Direction"<<"Tx Directison"<<"TxRq Direction";
    tableWidget->setHorizontalHeaderLabels(m1_TableHeader);
    tableWidget->verticalHeader()->setVisible(false);
    m_HeaderView->sectionResizeMode(QHeaderView::Stretch);
    tableWidget->setHorizontalHeader(m_HeaderView);


    //tableWidget->setShowGrid(false);

    //Add Table items here
    tableWidget->setItem(0,0, new QTableWidgetItem("64 - 67"));
    tableWidget->setCellWidget(0,1,new QLabel("     CAN-Range"));
    QComboBox *ComboboxChannel = new QComboBox();
    ComboboxChannel->addItem("   CAN 1") ;
    ComboboxChannel->addItem("   CAN 2");
    ComboboxChannel->addItem("   CAN all");
    tableWidget->setCellWidget(0,2,ComboboxChannel);
    QCheckBox *Check1 = new QCheckBox;
        if(this->isEnabled())
        Check1->setChecked(true);
    QCheckBox *Check2 = new QCheckBox;
        if(this->isEnabled())
        Check2->setChecked(true);
    QCheckBox *Check3 =  new QCheckBox;
        if(this->isEnabled())
        Check3->setChecked(true);
    if(this->isEnabled())
    this->PassfilterButton->setChecked(true);
    if(this->isEnabled())
    this->FiltercheckBox->setChecked(true);
    tableWidget->setCellWidget(0,3,Check1);
    tableWidget->setCellWidget(0,4,Check2);
    tableWidget->setCellWidget(0,5,Check3);

    tableWidget->item(0,0)->setTextAlignment(Qt::AlignCenter);
    tableWidget->setSelectionBehavior(QAbstractItemView::SelectRows);
   // tableWidget->setSelectionMode(QAbstractItemView::NoSelection);

    connect(RawDataButton, SIGNAL(clicked()),this,SLOT(on_buttonRawData_click()));
    connect(OkButton,SIGNAL(clicked()),this,SLOT(on_buttonOk_accept()));
    connect(CancelButton, SIGNAL(clicked()),this,SLOT(on_buttonCancel_reject()));
    connect(HelpButton, SIGNAL(clicked()), this, SLOT(on_buttonHelp_click()));
    connect(RemoveButton, SIGNAL(clicked()),this, SLOT(slotRemoveRow()));
    connect(m_HeaderView,SIGNAL(sectionClicked(int)),this,SLOT(sectionClickedSlot(int)));
    connect(m_HeaderView,SIGNAL(sectionDoubleClicked(int)),this,SLOT(sectionDoubleClickedSlot(int)));
    //    tableWidget->resizeColumnsToContents();

    setWindowIcon(QPixmap(":/icons/logo.png"));
    setWindowTitle(tr("Filter"));
}

FilterManagerWindow::~FilterManagerWindow()
{
    delete this;
}

void FilterManagerWindow::closeEvent(QCloseEvent *event)
{
    //TODO: need to check change before asking
    QMessageBox::StandardButton resBtn = QMessageBox::question( this, "Filter",
                                                                tr("Do you want to save changes?\n"),
                                                                QMessageBox::Cancel | QMessageBox::No | QMessageBox::Yes,
                                                                QMessageBox::Cancel);
    if (resBtn == QMessageBox::Yes) {
        //TODO: Saving to database file
        event->accept();
    } else if (resBtn == QMessageBox::Cancel) {
        event->ignore();
    }else{
        //TODO: do not saving
        event->accept();
    }
}

void FilterManagerWindow::on_buttonRawData_click(){
    m_GetIdDialog = new DialogGetID(this);
    m_GetIdDialog->setModal(true);
    m_GetIdDialog->show();
    connect(m_GetIdDialog,SIGNAL(getId(int,int)),this,SLOT(slotGetID(int,int)));
}

void FilterManagerWindow::on_buttonOk_accept(){
    this->close();
}

void FilterManagerWindow::on_buttonCancel_reject(){
    this->close();
}

void FilterManagerWindow::on_buttonHelp_click()
{
   QMessageBox::information(this,tr("Filter Help"),tr("I'm sorry!\nI can't help you anything else."));
}

void FilterManagerWindow::slotGetID(int sID, int eID)
{

    if((sID)>=(eID)){
     QMessageBox::warning(this,"Attention","You have entered an invalid range or single value");
    }
    else{
#if 1
    tableWidget->insertRow(tableWidget->rowCount());
    int currentIndex = tableWidget->rowCount()-1;
    tableWidget->setItem(currentIndex,0, new QTableWidgetItem(QString::number(sID)+" - "+QString::number(eID)));
    tableWidget->setCellWidget(currentIndex,1,new QLabel("     CAN-Range"));
    tableWidget->item(currentIndex,0)->setTextAlignment(Qt::AlignCenter);
    QComboBox *ComboboxChannel = new QComboBox();
    ComboboxChannel->addItem("   CAN 1");
    ComboboxChannel->addItem("   CAN 2");
    ComboboxChannel->addItem("   CAN all");
    tableWidget->setCellWidget(currentIndex,2,ComboboxChannel);
    QCheckBox *Check1 = new QCheckBox;
        if(this->isEnabled())
        Check1->setChecked(true);
    QCheckBox *Check2 = new QCheckBox;
        if(this->isEnabled())
        Check2->setChecked(true);
    QCheckBox *Check3 =  new QCheckBox;
        if(this->isEnabled())
        Check3->setChecked(true);
    if(this->isEnabled())
    this->PassfilterButton->setChecked(true);
    if(this->isEnabled())
    this->FiltercheckBox->setChecked(true);
    tableWidget->setCellWidget(currentIndex,3,Check1);
    tableWidget->setCellWidget(currentIndex,4,Check2);
    tableWidget->setCellWidget(currentIndex,5,Check3);}
#endif
}

void FilterManagerWindow::slotRemoveRow()
{

    tableWidget->setSelectionBehavior(QAbstractItemView::SelectRows);
    tableWidget->removeRow(this->tableWidget->currentRow());
}

void FilterManagerWindow::sectionDoubleClickedSlot(int index)
{

    if(count){
    tableWidget->sortByColumn(index,Qt::AscendingOrder);
    count =! count;
    }
    else{
        tableWidget->sortByColumn(index,Qt::DescendingOrder);
        count =!count;
    }
}

void FilterManagerWindow::sectionClickedSlot(int index)
{
  if(index<=0) return;
  tableWidget->setSelectionMode(QAbstractItemView::SingleSelection);
  tableWidget->setSelectionBehavior(QAbstractItemView::SelectColumns);
  tableWidget->selectColumn(index);
  tableWidget->setSelectionMode(QAbstractItemView::NoSelection);
}

