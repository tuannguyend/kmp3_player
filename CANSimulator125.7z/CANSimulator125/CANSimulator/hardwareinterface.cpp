#include "hardwareinterface.h"
#include "ui_hardwareinterface.h"
#include <QGroupBox>
#include <QLabel>
#include <QLineEdit>
#include <QGridLayout>
#include <QWidget>
#include <QStackedWidget>
#include <QMessageBox>
#include <QCloseEvent>
#include <QComboBox>
HardwareInterface::HardwareInterface(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::HardwareInterface)
{
    ui->setupUi(this);
    ui->StackCAN->removeWidget(ui->m_pageCAN1);
    ui->StackCAN->removeWidget(ui->m_pageCAN2);
    ui->StackCAN->addWidget(ui->m_CAN1group);
    ui->StackCAN->addWidget(ui->m_CAN2group);
    ui->StackCAN->addWidget(ui->m_pageMain);
    QLabel *main = new QLabel(tr("Hardware configuration\nFPT CAN team"));
    QLabel *typeCANLabel1 = new QLabel(tr("Type:"));
    QLabel *DemoLabel1 = new QLabel(tr("Demo"));
    QLabel *ControllerLabel1 = new QLabel(tr("Controller:"));
    QLabel *PhilipLabel1 = new QLabel(tr("Philips SJA1000"));
    QLabel *BaudrateLabel1 = new QLabel(tr("Baudrate[kbaud]:"));
    QComboBox *BaudrateCombobox1 = new QComboBox();
    BaudrateCombobox1->addItem("33.3");
    BaudrateCombobox1->addItem("50");
    BaudrateCombobox1->addItem("83.3");
    BaudrateCombobox1->addItem("100");
    BaudrateCombobox1->addItem("250");
    BaudrateCombobox1->addItem("500");
    BaudrateCombobox1->addItem("1000");


    QLabel *typeCANLabel2 = new QLabel(tr("Type:"));
    QLabel *DemoLabel2 = new QLabel(tr("Demo"));
    QLabel *ControllerLabel2 = new QLabel(tr("Controller:"));
    QLabel *PhilipLabel2 = new QLabel(tr("Philips SJA1000"));
    QLabel *BaudrateLabel2 = new QLabel(tr("Baudrate[kbaud]:"));
    QComboBox *BaudrateCombobox2 = new QComboBox();
    BaudrateCombobox2->addItem("33.3");
    BaudrateCombobox2->addItem("50");
    BaudrateCombobox2->addItem("83.3");
    BaudrateCombobox2->addItem("100");
    BaudrateCombobox2->addItem("250");
    BaudrateCombobox2->addItem("500");
    BaudrateCombobox2->addItem("1000");

    QGridLayout *mainLayout2 =  new QGridLayout;
    mainLayout2->addWidget(main,0,0,1,2);
    ui->m_pageMain->setLayout(mainLayout2);
    ui->StackCAN->setCurrentWidget(ui->m_pageMain);

    QGridLayout *mainLayout =  new QGridLayout;
    mainLayout->addWidget(typeCANLabel1,0,0,1,1);
    mainLayout->addWidget(DemoLabel1,0,1,1,1);
    mainLayout->addWidget(ControllerLabel1,1,0,1,1);
    mainLayout->addWidget(PhilipLabel1,1,1,1,1);
    mainLayout->addWidget(BaudrateLabel1,2,0,1,1);
    mainLayout->addWidget(BaudrateCombobox1,2,1,1,1);
    ui->m_CAN1group->setLayout(mainLayout);

    QGridLayout *mainLayout1 =  new QGridLayout;
    mainLayout1->addWidget(typeCANLabel2,0,0,1,1);
    mainLayout1->addWidget(DemoLabel2,0,1,1,1);
    mainLayout1->addWidget(ControllerLabel2,1,0,1,1);
    mainLayout1->addWidget(PhilipLabel2,1,1,1,1);
    mainLayout1->addWidget(BaudrateLabel2,2,0,1,1);
    mainLayout1->addWidget(BaudrateCombobox2,2,1,1,1);
    ui->m_CAN2group->setLayout(mainLayout1);

    connect(ui->OkButton,SIGNAL(clicked()),this,SLOT(on_buttonOk_accept()));
    connect(ui->CancelButton, SIGNAL(clicked()),this,SLOT(on_buttonCancel_reject()));
    connect(ui->HelpButton, SIGNAL(clicked()), this, SLOT(on_buttonHelp_click()));
    setWindowTitle(tr("Hardware Configuration"));
    setWindowIcon(QPixmap(":/icons/logo.png"));
}


HardwareInterface::~HardwareInterface()
{
    delete ui;
}

void HardwareInterface::closeEvent(QCloseEvent *event)
{
    //TODO: need to check change before asking
    QMessageBox::StandardButton resBtn = QMessageBox::question( this, "Filter",
                                                                tr("Do you want to save changes?\n"),
                                                                QMessageBox::Cancel | QMessageBox::No | QMessageBox::Yes,
                                                                QMessageBox::Cancel);
    if (resBtn == QMessageBox::Yes) {
        //TODO: Saving to database file
        event->accept();
    } else if (resBtn == QMessageBox::Cancel) {
        event->ignore();
    }else{
        //TODO: do not saving
        event->accept();
        }

}

void HardwareInterface::on_ButtonCAN1_clicked()
{
    ui->StackCAN->setCurrentWidget(ui->m_CAN1group);
}

void HardwareInterface::on_ButtonCAN2_clicked()
{
    ui->StackCAN->setCurrentWidget(ui->m_CAN2group);

}

void HardwareInterface::on_buttonOk_accept()
{
    this->close();
}

void HardwareInterface::on_buttonCancel_reject()
{
    this->close();
}

void HardwareInterface::on_buttonHelp_click()
{
    QMessageBox::information(this,tr("Hardware configuration Help"),tr("I'm sorry!\nI can't help you anything else."));
}
