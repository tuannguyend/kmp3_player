#include <QCoreApplication>
#include <stdio.h>
#include "game.h"
#include <qjson/parser.h>

int main(int argc, char *argv[])
{
    QCoreApplication app(argc, argv);
    Game a;
    a.newGame();
    if (!a.saveGame(Game::Json))
         return 1;

    if (!a.saveGame(Game::Binary))
         return 1;

    return 0;
}

