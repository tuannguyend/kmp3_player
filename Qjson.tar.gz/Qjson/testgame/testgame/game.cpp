
#include "game.h"

#include <QFile>
#include <QJsonArray>
#include <QJsonDocument>

Game::Game()
{
}


//! [0]
void Game::newGame() {
    mPlayer = Character();
    mPlayer.setName(QStringLiteral("Join"));
    mPlayer.setClassType(Character::Archer);
    mPlayer.setLevel(2);



    mLevels.clear();

    Level village;
    QList<Character> villageNpcs;
    villageNpcs.append(Character(QStringLiteral("Tuan"), 10, Character::Warrior));
    villageNpcs.append(Character(QStringLiteral("Tuyen soi"), 10, Character::Warrior));
    village.setNpcs(villageNpcs);
    mLevels.append(village);



    Level tuan;
    QList<Character> tuanNpcs;
    tuanNpcs.append(Character(QStringLiteral("What"), 2, Character::Archer));
    tuanNpcs.append(Character(QStringLiteral("The"), 3, Character::Mage));
    tuanNpcs.append(Character(QStringLiteral("Hell,Qjson?"), 4, Character::Warrior));
    tuan.setNpcs(tuanNpcs);
    mLevels.append(tuan);

    Level dungeon;
    mLevels.append(dungeon);

}

bool Game::saveGame(Game::SaveFormat saveFormat) const
{
    QFile saveFile(saveFormat == Json
        ? QStringLiteral("save.cfg")
        : QStringLiteral("save.dat"));

    if (!saveFile.open(QIODevice::WriteOnly)) {
        qWarning("Couldn't open save file.");
        return false;
    }

    QJsonObject gameObject;
    write(gameObject);
    QJsonDocument saveDoc(gameObject);
    saveFile.write(saveFormat == Json
        ? saveDoc.toJson()
        : saveDoc.toBinaryData());

    return true;
}


void Game::write(QJsonObject &json) const
{
    QJsonObject playerObject;
    mPlayer.write(playerObject);
    json["player"] = playerObject;

    QJsonArray levelArray;
    foreach (const Level level, mLevels) {
        QJsonObject levelObject;
        level.write(levelObject);
        QJsonObject test;

        json["next"] =test;
        levelArray.append(levelObject);

    }
    json["levels"] = levelArray;

}
//! [2]
