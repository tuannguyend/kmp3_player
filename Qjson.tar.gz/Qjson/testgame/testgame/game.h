#ifndef GAME_H
#define GAME_H
#include<QJsonObject>
#include<QList>
#include"level.h"
class Game
{
public:
    Game();

    enum SaveFormat{
        Json, Binary
    };
    const Character &player() const;
    const QList<Level> &levels() const;

    void newGame();
    bool saveGame(SaveFormat saveFormat) const;
    void write(QJsonObject &json) const;
private:
    Character mPlayer;
    QList<Level> mLevels;
    int Can;
};

#endif // GAME_H

