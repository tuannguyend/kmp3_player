#include "input.h"

input::input()
{
}
