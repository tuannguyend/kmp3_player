#ifndef BAUD_H
#define BAUD_H
#include <QJsonObject>
class Baud
{
public:
    Baud();
    int Value() const;
    int Join() const;
    void setValue(int Value);
    void setJoin(int Join);
    void write(QJsonObject &json) const;
    void write1(QJsonObject &json1) const;

private:
    int mValue;
    int mJoin;
};

#endif // BAUD_H



