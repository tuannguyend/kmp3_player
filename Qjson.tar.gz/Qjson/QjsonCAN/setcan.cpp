#include "setcan.h"
#include <QJsonObject>
#include <QFile>
#include <QJsonArray>
#include <QJsonDocument>
#include <QDebug>
#include<QJsonValue>
#include <QList>
//setCAN::setCAN()
//{
//}
const QList<Baud> &setCAN::baud() const
{
    return mBaud;
}

void setCAN::setBaud(const QList<Baud> &baud)
{
    mBaud = baud;
}
const QList<Baud> &setCAN::join() const
{
    return mjoin;
}

void setCAN::setJoin(const QList<Baud> &join)
{
    mjoin = join;
}

void setCAN::write(QJsonObject &json) const {
    const Baud baud;
       QJsonObject baudObject;
       baud.write(baudObject);
   json["Baud"] = baudObject;
}
