#include "triggerblock.h"

TriggerBlock::TriggerBlock()
{
}
