#include "ingenblock.h"

IngenBlock::IngenBlock()
{
}
