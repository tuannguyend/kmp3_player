#ifndef CHANNELFILTER_H
#define CHANNELFILTER_H

class ChannelFilter
{
public:
    ChannelFilter();
};

#endif // CHANNELFILTER_H
