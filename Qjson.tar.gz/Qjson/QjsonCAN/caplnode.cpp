#include "caplnode.h"

CAPLnode::CAPLnode()
{
}
