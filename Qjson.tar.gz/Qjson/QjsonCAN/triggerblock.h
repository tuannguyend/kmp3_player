#ifndef TRIGGERBLOCK_H
#define TRIGGERBLOCK_H

class TriggerBlock
{
public:
    TriggerBlock();
};

#endif // TRIGGERBLOCK_H
