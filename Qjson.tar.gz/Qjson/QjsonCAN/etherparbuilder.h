#ifndef ETHERPARBUILDER_H
#define ETHERPARBUILDER_H

class EtherParBuilder
{
public:
    EtherParBuilder();
};

#endif // ETHERPARBUILDER_H
