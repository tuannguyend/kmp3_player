#ifndef BREAK_H
#define BREAK_H

class Break
{
public:
    Break();
};

#endif // BREAK_H
