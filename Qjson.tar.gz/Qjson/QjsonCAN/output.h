#ifndef OUTPUT_H
#define OUTPUT_H

class output
{
public:
    output();
};

#endif // OUTPUT_H
