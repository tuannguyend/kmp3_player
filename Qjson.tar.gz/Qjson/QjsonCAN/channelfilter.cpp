#include "channelfilter.h"

ChannelFilter::ChannelFilter()
{
}
