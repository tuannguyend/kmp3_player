#ifndef INPUT_H
#define INPUT_H

class input
{
public:
    input();
};

#endif // INPUT_H
