#ifndef REPLAYBLOCKCAN_H
#define REPLAYBLOCKCAN_H

class ReplayBlockCan
{
public:
    ReplayBlockCan();
};

#endif // REPLAYBLOCKCAN_H
