#include "baud.h"
#include <QJsonObject>

Baud::Baud(): mValue(0)
{
}


int Baud::Value() const
{
    return mValue;
}

void Baud::setValue(int Value)
{
    mValue = Value;
}
int Baud::Join() const
{
    return mJoin;
}

void Baud::setJoin(int Join)
{
    mJoin = Join;
}



void Baud::write(QJsonObject &json) const
{
    json["Baud"] = mValue;


}

void Baud::write1(QJsonObject &json1) const
{
    json1["Join"] = mJoin;


}
