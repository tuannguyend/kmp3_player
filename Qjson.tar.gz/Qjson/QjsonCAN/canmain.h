#ifndef CANMAIN_H
#define CANMAIN_H
#include <QJsonObject>
#include <QList>
#include "baud.h"
#include <QVector>
#include "setcan.h"
class CANmain
{
public:
    CANmain();

    enum SaveFormat{
        Json, Binary
    };

    CANmain(int CanValue);
    int CanValue() const;
    void setCanValue(int CanValue);
    void newCANmain();
    bool saveCAN(SaveFormat saveFormat) const;
    void write(QJsonObject &json) const;
private:
    Baud mBaud;
    Baud mJoin;
    int mCanValue;


};

#endif // CANMAIN_H


