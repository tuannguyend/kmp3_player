ifndef CAPLNODE_H
#define CAPLNODE_H

class CAPLnode
{
public:
    CAPLnode();
};

#endif // CAPLNODE_H
