#ifndef INGENBLOCK_H
#define INGENBLOCK_H

class IngenBlock
{
public:
    IngenBlock();
};

#endif // INGENBLOCK_H
