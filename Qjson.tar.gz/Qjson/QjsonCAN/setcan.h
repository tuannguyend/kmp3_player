#ifndef SETCAN_H
#define SETCAN_H
#include <QJsonObject>
#include "baud.h"
#include <QList>
class setCAN
{
public:
    setCAN();

     const QList<Baud> &baud() const;
     void setBaud(const QList<Baud> &baud);
     const QList<Baud> &join() const;
     void setJoin(const QList<Baud> &join);
     void write(QJsonObject &json) const;

     QList<Baud> &mBaud;
     QList<Baud> &mjoin;
 };

#endif
