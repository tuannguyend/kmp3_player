#include "output.h"

output::output()
{
}
