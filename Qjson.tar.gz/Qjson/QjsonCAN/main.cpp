#include <QCoreApplication>
#include <stdio.h>
#include "canmain.h"
#include <qjson/parser.h>
#include <QDebug>
#include <QJsonParseError>
#include <QJsonDocument>
#include <QJsonObject>
#include <QByteArray>
#include <QStringList>
#include <QFile>

void Get();
int main(int argc, char *argv[])
{
    QCoreApplication app(argc, argv);
    CANmain a;
    a.newCANmain();


  if (!a.saveCAN(CANmain::Json))

    return 1;


    if (!a.saveCAN(CANmain::Binary))
         return 1;
   // Get();
    return 0;
}

void Get(){
    QFile myFile("/home/tuannd94/CAN/Json/Qjsonlast/Qjson/build-QjsonCAN-Desktop-Debug/save.cfg");
    myFile.open(QIODevice::ReadOnly);

    QJsonDocument jsonContent;
    QJsonObject roots;
    QString jsonString = QString::fromUtf8(myFile.readAll()).simplified();
    jsonContent = QJsonDocument::fromJson(jsonString.toUtf8());
    myFile.close();
    roots = jsonContent.object();

    qDebug ()<<"Root is:"<<roots;

    QJsonValueRef Objectref = roots.find("..CAN 1").value();

    qDebug ()<<"Find:"<<Objectref;
    QJsonObject ex = roots["..Main"].toObject();
    qDebug() << "ROOT WANTED:" <<ex;
    roots.insert("test",5);
    roots.insert("Player", 10);
    roots.insert(".Input", ex);
    roots.insert("..CAN 3", Objectref);
    qDebug()<<"Roots after insert\n"<<roots;

    roots.remove("Player");
    roots.remove("test");
    qDebug() <<"Root after remove\n"<<roots;
    myFile.open(QIODevice::WriteOnly);
    jsonContent .setObject(roots);
    //doc.setObject(roots);
    //   myFile.write(doc.toJson());
    myFile.write(jsonContent.toJson());
    myFile.close();
}

