#ifndef FILTER_H
#define FILTER_H

class Filter
{
public:
    Filter();
};

#endif // FILTER_H
