#include "filter.h"

Filter::Filter()
{
}
