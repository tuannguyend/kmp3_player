#include "canmain.h"
#include <QFile>
#include <QJsonArray>
#include <QJsonDocument>
#include <QDebug>
#include<QJsonValue>
#include <QList>

CANmain::CANmain()
{
}

void CANmain::newCANmain() {
    mBaud = Baud();
    mBaud.setValue(500);
    mJoin = Baud();
    mJoin.setJoin(100);
    
}


bool CANmain::saveCAN(CANmain::SaveFormat saveFormat) const
{
    QFile saveFile(saveFormat == Json
        ? QStringLiteral("save.cfg")
        : QStringLiteral("save.dat"));

    if (!saveFile.open(QIODevice::WriteOnly)) {
        qWarning("Couldn't open save file.");
        return false;
    }

    QJsonObject gameObject;
    write(gameObject);
    QJsonDocument saveDoc(gameObject);
    saveFile.write(saveFormat == Json
        ? saveDoc.toJson()
        : saveDoc.toBinaryData());

    return true;
}


void CANmain::write(QJsonObject &json) const
{

   json["..CAN"] = QJsonValue(2);
    QJsonObject Can1Object;
    mBaud.write(Can1Object);
    json["..CAN 1"]= Can1Object;

    QJsonObject Can2Object;
    mBaud.write(Can2Object);
    json["..CAN 2"]= Can2Object;


    QJsonObject MainObject;
    mJoin.write1(MainObject);
    json["..Main"]= MainObject;

    QJsonObject InputObject;
    json[".Input"]= InputObject;

    QJsonObject GenObject;
    json["Generate"]= GenObject;

}





