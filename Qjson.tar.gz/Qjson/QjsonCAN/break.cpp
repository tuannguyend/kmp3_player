#include "break.h"

Break::Break()
{
}
