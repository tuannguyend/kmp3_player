#include <QJsonParseError>
#include <QJsonDocument>
#include <QJsonObject>

#include <QByteArray>
#include <QStringList>
#include <QDebug>
#include <QFile>

int main()
{
    QFile file("/home/trungnt32/CAN/Qjson/getobject/save.cfg");
    if (!file.open(QIODevice::ReadOnly | QIODevice::Text)) {
        qDebug() << "File open error:" << file.errorString();
        return 1;
    }

    QByteArray jsonByteArray = file.readAll();

    file.close();

    QJsonParseError jsonParseError;
    QJsonDocument jsonDocument = QJsonDocument::fromJson(jsonByteArray, &jsonParseError);
    if (jsonParseError.error != QJsonParseError::NoError) {
        qDebug() << "Error happened:" << jsonParseError.errorString();
        return 1;
    }

    if (!jsonDocument.isObject()) {
        qDebug() << "The json data is not an object";
        return 1;
    }

    QJsonObject mainJsonObject(jsonDocument.object());

    QJsonValue returnJsonValue = mainJsonObject.value(QStringLiteral("..CAN 1"));

    if (!returnJsonValue.isObject()) {
        qDebug() << "The json data is not an object";
        return 1;
    }

    qDebug() << "ROOT WANTED:" << returnJsonValue.toObject().keys();

    return 0;
}
