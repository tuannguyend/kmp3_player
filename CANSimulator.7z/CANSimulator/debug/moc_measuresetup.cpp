/****************************************************************************
** Meta object code from reading C++ file 'measuresetup.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.8.0)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../measuresetup.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'measuresetup.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.8.0. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_MeasureSetupWindow_t {
    QByteArrayData data[1];
    char stringdata0[19];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_MeasureSetupWindow_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_MeasureSetupWindow_t qt_meta_stringdata_MeasureSetupWindow = {
    {
QT_MOC_LITERAL(0, 0, 18) // "MeasureSetupWindow"

    },
    "MeasureSetupWindow"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_MeasureSetupWindow[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

       0        // eod
};

void MeasureSetupWindow::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    Q_UNUSED(_o);
    Q_UNUSED(_id);
    Q_UNUSED(_c);
    Q_UNUSED(_a);
}

const QMetaObject MeasureSetupWindow::staticMetaObject = {
    { &QMainWindow::staticMetaObject, qt_meta_stringdata_MeasureSetupWindow.data,
      qt_meta_data_MeasureSetupWindow,  qt_static_metacall, Q_NULLPTR, Q_NULLPTR}
};


const QMetaObject *MeasureSetupWindow::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *MeasureSetupWindow::qt_metacast(const char *_clname)
{
    if (!_clname) return Q_NULLPTR;
    if (!strcmp(_clname, qt_meta_stringdata_MeasureSetupWindow.stringdata0))
        return static_cast<void*>(const_cast< MeasureSetupWindow*>(this));
    if (!strcmp(_clname, "Ui_MeasureSetup"))
        return static_cast< Ui_MeasureSetup*>(const_cast< MeasureSetupWindow*>(this));
    return QMainWindow::qt_metacast(_clname);
}

int MeasureSetupWindow::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    return _id;
}
struct qt_meta_stringdata_MeasureSetupItemCommon_t {
    QByteArrayData data[6];
    char stringdata0[61];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_MeasureSetupItemCommon_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_MeasureSetupItemCommon_t qt_meta_stringdata_MeasureSetupItemCommon = {
    {
QT_MOC_LITERAL(0, 0, 22), // "MeasureSetupItemCommon"
QT_MOC_LITERAL(1, 23, 8), // "sendData"
QT_MOC_LITERAL(2, 32, 0), // ""
QT_MOC_LITERAL(3, 33, 14), // "MessageCommon*"
QT_MOC_LITERAL(4, 48, 4), // "data"
QT_MOC_LITERAL(5, 53, 7) // "rcvData"

    },
    "MeasureSetupItemCommon\0sendData\0\0"
    "MessageCommon*\0data\0rcvData"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_MeasureSetupItemCommon[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
       3,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       1,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    1,   29,    2, 0x06 /* Public */,

 // slots: name, argc, parameters, tag, flags
       5,    1,   32,    2, 0x0a /* Public */,
       5,    0,   35,    2, 0x2a /* Public | MethodCloned */,

 // signals: parameters
    QMetaType::Void, 0x80000000 | 3,    4,

 // slots: parameters
    QMetaType::Void, 0x80000000 | 3,    4,
    QMetaType::Void,

       0        // eod
};

void MeasureSetupItemCommon::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        MeasureSetupItemCommon *_t = static_cast<MeasureSetupItemCommon *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->sendData((*reinterpret_cast< MessageCommon*(*)>(_a[1]))); break;
        case 1: _t->rcvData((*reinterpret_cast< MessageCommon*(*)>(_a[1]))); break;
        case 2: _t->rcvData(); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        void **func = reinterpret_cast<void **>(_a[1]);
        {
            typedef void (MeasureSetupItemCommon::*_t)(MessageCommon * );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&MeasureSetupItemCommon::sendData)) {
                *result = 0;
                return;
            }
        }
    }
}

const QMetaObject MeasureSetupItemCommon::staticMetaObject = {
    { &QObject::staticMetaObject, qt_meta_stringdata_MeasureSetupItemCommon.data,
      qt_meta_data_MeasureSetupItemCommon,  qt_static_metacall, Q_NULLPTR, Q_NULLPTR}
};


const QMetaObject *MeasureSetupItemCommon::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *MeasureSetupItemCommon::qt_metacast(const char *_clname)
{
    if (!_clname) return Q_NULLPTR;
    if (!strcmp(_clname, qt_meta_stringdata_MeasureSetupItemCommon.stringdata0))
        return static_cast<void*>(const_cast< MeasureSetupItemCommon*>(this));
    return QObject::qt_metacast(_clname);
}

int MeasureSetupItemCommon::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QObject::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 3)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 3;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 3)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 3;
    }
    return _id;
}

// SIGNAL 0
void MeasureSetupItemCommon::sendData(MessageCommon * _t1)
{
    void *_a[] = { Q_NULLPTR, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}
struct qt_meta_stringdata_MeasureSetupItemJoin_t {
    QByteArrayData data[1];
    char stringdata0[21];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_MeasureSetupItemJoin_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_MeasureSetupItemJoin_t qt_meta_stringdata_MeasureSetupItemJoin = {
    {
QT_MOC_LITERAL(0, 0, 20) // "MeasureSetupItemJoin"

    },
    "MeasureSetupItemJoin"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_MeasureSetupItemJoin[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

       0        // eod
};

void MeasureSetupItemJoin::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    Q_UNUSED(_o);
    Q_UNUSED(_id);
    Q_UNUSED(_c);
    Q_UNUSED(_a);
}

const QMetaObject MeasureSetupItemJoin::staticMetaObject = {
    { &MeasureSetupItemCommon::staticMetaObject, qt_meta_stringdata_MeasureSetupItemJoin.data,
      qt_meta_data_MeasureSetupItemJoin,  qt_static_metacall, Q_NULLPTR, Q_NULLPTR}
};


const QMetaObject *MeasureSetupItemJoin::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *MeasureSetupItemJoin::qt_metacast(const char *_clname)
{
    if (!_clname) return Q_NULLPTR;
    if (!strcmp(_clname, qt_meta_stringdata_MeasureSetupItemJoin.stringdata0))
        return static_cast<void*>(const_cast< MeasureSetupItemJoin*>(this));
    return MeasureSetupItemCommon::qt_metacast(_clname);
}

int MeasureSetupItemJoin::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = MeasureSetupItemCommon::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    return _id;
}
struct qt_meta_stringdata_MeasureSetupItemFilter_t {
    QByteArrayData data[1];
    char stringdata0[23];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_MeasureSetupItemFilter_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_MeasureSetupItemFilter_t qt_meta_stringdata_MeasureSetupItemFilter = {
    {
QT_MOC_LITERAL(0, 0, 22) // "MeasureSetupItemFilter"

    },
    "MeasureSetupItemFilter"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_MeasureSetupItemFilter[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

       0        // eod
};

void MeasureSetupItemFilter::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    Q_UNUSED(_o);
    Q_UNUSED(_id);
    Q_UNUSED(_c);
    Q_UNUSED(_a);
}

const QMetaObject MeasureSetupItemFilter::staticMetaObject = {
    { &MeasureSetupItemCommon::staticMetaObject, qt_meta_stringdata_MeasureSetupItemFilter.data,
      qt_meta_data_MeasureSetupItemFilter,  qt_static_metacall, Q_NULLPTR, Q_NULLPTR}
};


const QMetaObject *MeasureSetupItemFilter::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *MeasureSetupItemFilter::qt_metacast(const char *_clname)
{
    if (!_clname) return Q_NULLPTR;
    if (!strcmp(_clname, qt_meta_stringdata_MeasureSetupItemFilter.stringdata0))
        return static_cast<void*>(const_cast< MeasureSetupItemFilter*>(this));
    return MeasureSetupItemCommon::qt_metacast(_clname);
}

int MeasureSetupItemFilter::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = MeasureSetupItemCommon::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    return _id;
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
