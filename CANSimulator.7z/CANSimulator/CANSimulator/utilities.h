#ifndef UTILITIES_H
#define UTILITIES_H
#include "CANDefines.h"

typedef union{
    struct __sine{
        unsigned int m_Cycle;
        long long int m_Amplitude;
        long long int m_Offset;
        float m_Phase;
    }m_Sine;
    struct __square{
        unsigned int m_CycleH;
        long long int m_PeakH;
        unsigned int m_CycleL;
        long long int m_PeakL;
    }m_Square;
}U_CANSignalWaveData;

class CANSignalSimulate{
public:
    CANSignalSimulate(){}
    ~CANSignalSimulate(){}
    unsigned char m_StartBit;
    CANSignal m_CANSign;
    E_CANSignalWaveForm m_WaveForm;
    U_CANSignalWaveData m_WaveFormProperties;
    U_CANValue m_Value;
    void pack(unsigned char * data, unsigned long long timestamp); /*For transmit*/
    void unpack(unsigned char * data); /*For transmit and receive*/
};

class CANMessageSimulate{
public:
    void pack(unsigned long long timestamp);
    void unpack();
    CANMessageSimulate(){}
    ~CANMessageSimulate(){}
    QVector<CANSignalSimulate> m_CANSignals;
    QString m_DbPath;
    unsigned int m_Id;
    unsigned char m_Len;
    unsigned char m_Data[8];
};

#endif // UTILITIES_H
