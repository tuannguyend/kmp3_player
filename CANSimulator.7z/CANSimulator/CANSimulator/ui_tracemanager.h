/********************************************************************************
** Form generated from reading UI file 'tracemanager.ui'
**
** Created by: Qt User Interface Compiler version 5.8.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_TRACEMANAGER_H
#define UI_TRACEMANAGER_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_TraceManager
{
public:
    QMenuBar *menubar;
    QWidget *centralwidget;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *TraceManager)
    {
        if (TraceManager->objectName().isEmpty())
            TraceManager->setObjectName(QStringLiteral("TraceManager"));
        TraceManager->resize(800, 600);
        menubar = new QMenuBar(TraceManager);
        menubar->setObjectName(QStringLiteral("menubar"));
        TraceManager->setMenuBar(menubar);
        centralwidget = new QWidget(TraceManager);
        centralwidget->setObjectName(QStringLiteral("centralwidget"));
        TraceManager->setCentralWidget(centralwidget);
        statusbar = new QStatusBar(TraceManager);
        statusbar->setObjectName(QStringLiteral("statusbar"));
        TraceManager->setStatusBar(statusbar);

        retranslateUi(TraceManager);

        QMetaObject::connectSlotsByName(TraceManager);
    } // setupUi

    void retranslateUi(QMainWindow *TraceManager)
    {
        TraceManager->setWindowTitle(QApplication::translate("TraceManager", "MainWindow", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class TraceManager: public Ui_TraceManager {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_TRACEMANAGER_H
