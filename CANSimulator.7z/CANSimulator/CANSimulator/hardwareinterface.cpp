#include "hardwareinterface.h"

HardwareInterface::HardwareInterface()
{
}
