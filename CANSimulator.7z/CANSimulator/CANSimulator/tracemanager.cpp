#include <QtGui>
#include "tracemanager.h"
#include "ui_tracemanager.h"
#include <tracedragdropmodel.h>
#include <tracetreemodel.h>
#include<QStringList>
#include <QTreeView>
TraceManager::TraceManager(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::TraceManager)
{
    ui->setupUi(this);
    ui->treeView->setDragEnabled(true);
    ui->treeView->setAcceptDrops(true);
   // this->treeView = treeView;
     setupItems();

    setCentralWidget(ui->treeView);
    setWindowTitle(tr("Trace"));
    setWindowIcon(QPixmap(":/icons/logo.png"));
}

TraceManager::~TraceManager()
{
    delete ui;
}

void TraceManager::setupItems()
{
    QStringList items;
    items << tr("New_Message_1\t(0x01)")
          << tr("  New_Signal_1\t")
          << tr("  New_Signal_2\t")
          << tr("New_Message_2\t(0x02)")
          << tr("  New_Signal_3\t")
          << tr("  New_Signal_4\t");
    TraceDragDropModel *model = new TraceDragDropModel(items, this);

    QModelIndex index = model->index(0, 0, QModelIndex());
    model->insertRows(2, 3, index);
    index = model->index(0, 0, QModelIndex());
    index = model->index(2, 0, index);
    model->setData(index, QVariant("New_Signal_5"));
    model->removeRows(3, 2, index.parent());
    ui->treeView->setModel(model);

}
