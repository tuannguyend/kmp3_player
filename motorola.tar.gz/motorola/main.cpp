#include <stdio.h>
#include "motorola.h"
#include "motorola.c"
#define max 8
#include <stdbool.h>



int main()
{
    float x,y,g;
    //uint8_t *b;
    //b = &reverse_mask[2];
    //x= CANMotorolaGetFloat(reverse_mask,2,9,9,0.1,0.5);
 //    x = get_bitfield(&reverse_mask[1],3,3,19);
    y = get_bitfield(reverse_mask,2,0,12);
    printf(" %f\n %ld\n",y,sizeof(reverse_mask));
  //  printf("\n");
    uint64_t d = 0xff7fffff;
    printf("\n");
    printf("d:%ld\n",sizeof(d));
    printf("Set\n");
    set_bitfield(d,0,12,destination,2);

    g =get_bitfield(destination,2,0,12);

    printf("%ffgdfgd\n",g);

    return 0;
}
