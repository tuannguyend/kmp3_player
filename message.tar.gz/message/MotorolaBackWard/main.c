
#include <stdio.h>
#include "motorolaBW.c"

#include <stdbool.h>

int main()
{
      //  float x,y,g;
        byteArray value1;
       int i=0;
        printf("\n");
        value1.v64 = get_bitfield(reverse_mask,2,4,10);

      //  printf("Check GET:", value1.v64);


        set_bitfield(value1.v64,4,10,testset,2);

        return 0;

}

