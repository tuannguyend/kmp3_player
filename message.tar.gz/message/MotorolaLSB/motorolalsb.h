#ifndef MOTOROLALSB_H
#define MOTOROLALSB_H

class motorolaLSB
{
public:
    motorolaLSB();
};

#endif // MOTOROLALSB_H
