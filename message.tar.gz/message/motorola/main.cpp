#include <stdio.h>
#include "motorola.h"
#include "motorola.c"
#define max 8
#include <stdbool.h>

int main()
{

    byteArray value1;

    int i=0;
    printf("\n");

    value1.v64 = get_bitfield(reverse_mask,2,4,10);

    printf("Check GET:", value1.v64);

    /*set_bitfield(value1.v64,4,10,testset,2);
    for (i=0;i<sizeof(testset);i++)
    {
        printf("\nvalue of testset: %x ",testset[i]);
    }
    */
    return 0;
}


