#ifndef HARDWAREINTERFACE_H
#define HARDWAREINTERFACE_H

class HardwareInterface
{
public:
    HardwareInterface();
};

#endif // HARDWAREINTERFACE_H
