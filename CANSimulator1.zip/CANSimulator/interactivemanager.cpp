#include "interactivemanager.h"
#include "ui_interactivemanager.h"

InteractiveManager::InteractiveManager(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::InteractiveManager)
{
    ui->setupUi(this);
}

InteractiveManager::~InteractiveManager()
{
    delete ui;
}
