#ifndef TRACETREEITEM_H
#define TRACETREEITEM_H
#include <QList>
#include <QVariant>

class TraceTreeItem
{
public:
    TraceTreeItem(const QList<QVariant> &data, TraceTreeItem *parent = 0);
    ~TraceTreeItem();

    void appendChild(TraceTreeItem *child);

    TraceTreeItem *child(int row);
    int childCount() const;
    int columnCount() const;
    QVariant data(int column) const;
    bool insertChild(int row, TraceTreeItem *item);
    TraceTreeItem *parent();
    bool removeChild(int row);
    int row() const;
    bool setData(int column, const QVariant &data);

private:
    QList<TraceTreeItem*> childItems;
    QList<QVariant> itemData;
    TraceTreeItem *parentItem;
};

#endif // TRACETREEITEM_H
