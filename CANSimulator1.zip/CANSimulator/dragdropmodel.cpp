#include "dragdropmodel.h"

DragDropModel::DragDropModel()
{

}
