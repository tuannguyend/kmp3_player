//#include "hardwareinterface.h"
//#include "ui_hardwareinterface.h"
//#include <QGroupBox>
//#include <QLabel>
//#include <QLineEdit>
//#include <QGridLayout>
//#include <QWidget>
//HardwareInterface::HardwareInterface(QWidget *parent) :
//    QDialog(parent),
//    ui(new Ui::HardwareInterface)
//{
//    ui->setupUi(this);
//    QLabel *typeCANLabel = new QLabel(tr("Type:"));
//    QLabel *DemoLabel = new QLabel(tr("Demo"));
////    QLabel *ControllerLabel = new QLabel(tr("Controller:"));
////    QLabel *PhilipLabel = new QLabel(tr("Philips SJA1000"));
////    QLabel *BaudrateLabel = new QLabel(tr("Baudrate[kbaud]:"));
////    QLineEdit *BaudrateLineEdit = new QLineEdit();
//   // ui->StackCAN->addWidget(CAN1GroupBox);
//    ui->StackCAN->removeWidget(m_pageCAN1);
//    ui->StackCAN->removeWidget(m_pageCAN2);
//    ui->StackCAN->addWidget(m_CAN1group);
//    ui->
//    QGridLayout *mainLayout =  new QGridLayout;
//    mainLayout->addWidget(typeCANLabel,0,0,1,1);

//    ui->->setLayout(mainLayout);
//    QGridLayout *mainLayout1 =  new QGridLayout;
//    mainLayout1->addWidget(DemoLabel,0,0,1,1);
//    ui->CAN2GroupBox->setLayout(mainLayout1);

//    connect(ui->ButtonCAN1,SIGNAL(clicked()),SLOT(ui->CAN1GroupBox->show()));
//    connect(ui->ButtonCAN2,SIGNAL(clicked(bool)),SLOT(ui->CAN2GroupBox->show()));
//  //     ui->StackCAN->addWidget(m_CAN)
//      //setLayout(BoxCAN1);
//    setWindowTitle(tr("Hardware Configuration"));
//    setWindowIcon(QPixmap(":/icons/logo.png"));
////    QGroupBox *BoxCAN2 = new QGroupBox(tr("CAN Channel 2"));
//}
////setupUi(this);
////QSplitter * splitter = new QSplitter(Qt::Horizontal,this);
////splitter->addWidget(m_treeWidget);
////splitter->addWidget(m_stackedWidget);
////QGridLayout * gridLayout = new QGridLayout;
////gridLayout->addWidget(splitter);
////centralWidget()->setLayout(gridLayout);
////m_stackedWidget->removeWidget(m_pageCom);
////m_stackedWidget->removeWidget(m_pageSignals);
////m_stackedWidget->removeWidget(m_pageMsgs);
////m_stackedWidget->addWidget(m_MsgsTableWidget);
////m_stackedWidget->addWidget(m_SignsTableWidget);
////m_stackedWidget->addWidget(m_ComTableWidget);

//HardwareInterface::~HardwareInterface()
//{
//    delete ui;
//}
