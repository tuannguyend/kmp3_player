#ifndef HARDWAREINTERFACE_H
#define HARDWAREINTERFACE_H

#include <QDialog>

namespace Ui {
class HardwareInterface;
}

class HardwareInterface : public QDialog
{
    Q_OBJECT

public:
    explicit HardwareInterface(QWidget *parent = 0);
    ~HardwareInterface();

private:
    Ui::HardwareInterface *ui;
};

#endif // HARDWAREINTERFACE_H
