/********************************************************************************
** Form generated from reading UI file 'filtermanager.ui'
**
** Created by: Qt User Interface Compiler version 5.8.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_FILTERMANAGER_H
#define UI_FILTERMANAGER_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QCheckBox>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QRadioButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QTableWidget>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_FilterManager
{
public:
    QWidget *centralwidget;
    QGridLayout *gridLayout_3;
    QTableWidget *tableWidget;
    QHBoxLayout *horizontalLayout_4;
    QVBoxLayout *verticalLayout;
    QHBoxLayout *horizontalLayout;
    QPushButton *RawDataButton;
    QPushButton *RemoveButton;
    QGroupBox *groupBox;
    QGridLayout *gridLayout_2;
    QRadioButton *PassfilterButton;
    QRadioButton *StopfilterButton;
    QVBoxLayout *verticalLayout_3;
    QSpacerItem *horizontalSpacer;
    QVBoxLayout *verticalLayout_2;
    QHBoxLayout *horizontalLayout_3;
    QCheckBox *FiltercheckBox;
    QSpacerItem *horizontalSpacer_3;
    QHBoxLayout *horizontalLayout_2;
    QSpacerItem *horizontalSpacer_2;
    QGridLayout *gridLayout;
    QPushButton *HelpButton;
    QPushButton *OkButton;
    QPushButton *CancelButton;
    QMenuBar *menubar;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *FilterManager)
    {
        if (FilterManager->objectName().isEmpty())
            FilterManager->setObjectName(QStringLiteral("FilterManager"));
        FilterManager->resize(753, 617);
        centralwidget = new QWidget(FilterManager);
        centralwidget->setObjectName(QStringLiteral("centralwidget"));
        gridLayout_3 = new QGridLayout(centralwidget);
        gridLayout_3->setObjectName(QStringLiteral("gridLayout_3"));
        tableWidget = new QTableWidget(centralwidget);
        tableWidget->setObjectName(QStringLiteral("tableWidget"));
        tableWidget->setMaximumSize(QSize(1677721, 1677721));

        gridLayout_3->addWidget(tableWidget, 0, 0, 1, 1);

        horizontalLayout_4 = new QHBoxLayout();
        horizontalLayout_4->setObjectName(QStringLiteral("horizontalLayout_4"));
        verticalLayout = new QVBoxLayout();
        verticalLayout->setObjectName(QStringLiteral("verticalLayout"));
        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setObjectName(QStringLiteral("horizontalLayout"));
        RawDataButton = new QPushButton(centralwidget);
        RawDataButton->setObjectName(QStringLiteral("RawDataButton"));

        horizontalLayout->addWidget(RawDataButton);

        RemoveButton = new QPushButton(centralwidget);
        RemoveButton->setObjectName(QStringLiteral("RemoveButton"));

        horizontalLayout->addWidget(RemoveButton);


        verticalLayout->addLayout(horizontalLayout);

        groupBox = new QGroupBox(centralwidget);
        groupBox->setObjectName(QStringLiteral("groupBox"));
        gridLayout_2 = new QGridLayout(groupBox);
        gridLayout_2->setObjectName(QStringLiteral("gridLayout_2"));
        PassfilterButton = new QRadioButton(groupBox);
        PassfilterButton->setObjectName(QStringLiteral("PassfilterButton"));

        gridLayout_2->addWidget(PassfilterButton, 0, 0, 1, 1);

        StopfilterButton = new QRadioButton(groupBox);
        StopfilterButton->setObjectName(QStringLiteral("StopfilterButton"));

        gridLayout_2->addWidget(StopfilterButton, 1, 0, 1, 1);


        verticalLayout->addWidget(groupBox);


        horizontalLayout_4->addLayout(verticalLayout);

        verticalLayout_3 = new QVBoxLayout();
        verticalLayout_3->setObjectName(QStringLiteral("verticalLayout_3"));
        horizontalSpacer = new QSpacerItem(568, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        verticalLayout_3->addItem(horizontalSpacer);

        verticalLayout_2 = new QVBoxLayout();
        verticalLayout_2->setObjectName(QStringLiteral("verticalLayout_2"));
        horizontalLayout_3 = new QHBoxLayout();
        horizontalLayout_3->setObjectName(QStringLiteral("horizontalLayout_3"));
        FiltercheckBox = new QCheckBox(centralwidget);
        FiltercheckBox->setObjectName(QStringLiteral("FiltercheckBox"));

        horizontalLayout_3->addWidget(FiltercheckBox);

        horizontalSpacer_3 = new QSpacerItem(402, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_3->addItem(horizontalSpacer_3);


        verticalLayout_2->addLayout(horizontalLayout_3);

        horizontalLayout_2 = new QHBoxLayout();
        horizontalLayout_2->setObjectName(QStringLiteral("horizontalLayout_2"));
        horizontalSpacer_2 = new QSpacerItem(323, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_2->addItem(horizontalSpacer_2);

        gridLayout = new QGridLayout();
        gridLayout->setObjectName(QStringLiteral("gridLayout"));
        HelpButton = new QPushButton(centralwidget);
        HelpButton->setObjectName(QStringLiteral("HelpButton"));

        gridLayout->addWidget(HelpButton, 0, 2, 1, 1);

        OkButton = new QPushButton(centralwidget);
        OkButton->setObjectName(QStringLiteral("OkButton"));

        gridLayout->addWidget(OkButton, 0, 0, 1, 1);

        CancelButton = new QPushButton(centralwidget);
        CancelButton->setObjectName(QStringLiteral("CancelButton"));

        gridLayout->addWidget(CancelButton, 0, 1, 1, 1);


        horizontalLayout_2->addLayout(gridLayout);


        verticalLayout_2->addLayout(horizontalLayout_2);


        verticalLayout_3->addLayout(verticalLayout_2);


        horizontalLayout_4->addLayout(verticalLayout_3);


        gridLayout_3->addLayout(horizontalLayout_4, 1, 0, 1, 1);

        FilterManager->setCentralWidget(centralwidget);
        menubar = new QMenuBar(FilterManager);
        menubar->setObjectName(QStringLiteral("menubar"));
        menubar->setGeometry(QRect(0, 0, 753, 21));
        FilterManager->setMenuBar(menubar);
        statusbar = new QStatusBar(FilterManager);
        statusbar->setObjectName(QStringLiteral("statusbar"));
        FilterManager->setStatusBar(statusbar);

        retranslateUi(FilterManager);

        QMetaObject::connectSlotsByName(FilterManager);
    } // setupUi

    void retranslateUi(QMainWindow *FilterManager)
    {
        FilterManager->setWindowTitle(QApplication::translate("FilterManager", "MainWindow", Q_NULLPTR));
        RawDataButton->setText(QApplication::translate("FilterManager", "Raw Data", Q_NULLPTR));
        RemoveButton->setText(QApplication::translate("FilterManager", "Remove", Q_NULLPTR));
        groupBox->setTitle(QApplication::translate("FilterManager", "Filter Type", Q_NULLPTR));
        PassfilterButton->setText(QApplication::translate("FilterManager", "Pass Filter", Q_NULLPTR));
        StopfilterButton->setText(QApplication::translate("FilterManager", "Stop Filter", Q_NULLPTR));
        FiltercheckBox->setText(QApplication::translate("FilterManager", "Filter unconfigured status-and errorevents", Q_NULLPTR));
        HelpButton->setText(QApplication::translate("FilterManager", "Help", Q_NULLPTR));
        OkButton->setText(QApplication::translate("FilterManager", "OK", Q_NULLPTR));
        CancelButton->setText(QApplication::translate("FilterManager", "Cancel", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class FilterManager: public Ui_FilterManager {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_FILTERMANAGER_H
