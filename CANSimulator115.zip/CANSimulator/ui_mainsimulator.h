/********************************************************************************
** Form generated from reading UI file 'mainsimulator.ui'
**
** Created by: Qt User Interface Compiler version 5.8.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINSIMULATOR_H
#define UI_MAINSIMULATOR_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenu>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QToolBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainSimulator
{
public:
    QAction *actionNewConfig;
    QAction *actionOpenConfig;
    QAction *actionSave;
    QAction *actionSaveAs;
    QAction *actionQuit;
    QAction *actionMeasurement_setup;
    QAction *actionRemove;
    QAction *actionEditView;
    QAction *actionAbout_CAN_Simulator;
    QWidget *centralWidget;
    QMenuBar *menuBar;
    QMenu *menu_File;
    QMenu *menuView;
    QMenu *menuEdit;
    QMenu *menuHelp;
    QToolBar *mainToolBar;
    QStatusBar *statusBar;

    void setupUi(QMainWindow *MainSimulator)
    {
        if (MainSimulator->objectName().isEmpty())
            MainSimulator->setObjectName(QStringLiteral("MainSimulator"));
        MainSimulator->resize(400, 300);
        QIcon icon;
        icon.addFile(QStringLiteral(":/icons/logo.png"), QSize(), QIcon::Normal, QIcon::Off);
        MainSimulator->setWindowIcon(icon);
        MainSimulator->setIconSize(QSize(40, 40));
        actionNewConfig = new QAction(MainSimulator);
        actionNewConfig->setObjectName(QStringLiteral("actionNewConfig"));
        actionNewConfig->setCheckable(false);
        QIcon icon1;
        icon1.addFile(QStringLiteral(":/icons/new.png"), QSize(), QIcon::Normal, QIcon::Off);
        actionNewConfig->setIcon(icon1);
        actionOpenConfig = new QAction(MainSimulator);
        actionOpenConfig->setObjectName(QStringLiteral("actionOpenConfig"));
        QIcon icon2;
        icon2.addFile(QStringLiteral(":/icons/open.png"), QSize(), QIcon::Normal, QIcon::Off);
        actionOpenConfig->setIcon(icon2);
        actionSave = new QAction(MainSimulator);
        actionSave->setObjectName(QStringLiteral("actionSave"));
        QIcon icon3;
        icon3.addFile(QStringLiteral("icons/save.png"), QSize(), QIcon::Normal, QIcon::Off);
        actionSave->setIcon(icon3);
        actionSaveAs = new QAction(MainSimulator);
        actionSaveAs->setObjectName(QStringLiteral("actionSaveAs"));
        QIcon icon4;
        icon4.addFile(QStringLiteral("icons/saveas.png"), QSize(), QIcon::Normal, QIcon::Off);
        actionSaveAs->setIcon(icon4);
        actionQuit = new QAction(MainSimulator);
        actionQuit->setObjectName(QStringLiteral("actionQuit"));
        QIcon icon5;
        icon5.addFile(QStringLiteral("icons/quit.png"), QSize(), QIcon::Normal, QIcon::Off);
        actionQuit->setIcon(icon5);
        actionMeasurement_setup = new QAction(MainSimulator);
        actionMeasurement_setup->setObjectName(QStringLiteral("actionMeasurement_setup"));
        QIcon icon6;
        icon6.addFile(QStringLiteral("icons/connection.png"), QSize(), QIcon::Normal, QIcon::Off);
        actionMeasurement_setup->setIcon(icon6);
        actionRemove = new QAction(MainSimulator);
        actionRemove->setObjectName(QStringLiteral("actionRemove"));
        QIcon icon7;
        icon7.addFile(QStringLiteral("icons/remove.png"), QSize(), QIcon::Normal, QIcon::Off);
        actionRemove->setIcon(icon7);
        actionEditView = new QAction(MainSimulator);
        actionEditView->setObjectName(QStringLiteral("actionEditView"));
        QIcon icon8;
        icon8.addFile(QStringLiteral("icons/edit.png"), QSize(), QIcon::Normal, QIcon::Off);
        actionEditView->setIcon(icon8);
        actionAbout_CAN_Simulator = new QAction(MainSimulator);
        actionAbout_CAN_Simulator->setObjectName(QStringLiteral("actionAbout_CAN_Simulator"));
        QIcon icon9;
        icon9.addFile(QStringLiteral("icons/about.png"), QSize(), QIcon::Normal, QIcon::Off);
        actionAbout_CAN_Simulator->setIcon(icon9);
        centralWidget = new QWidget(MainSimulator);
        centralWidget->setObjectName(QStringLiteral("centralWidget"));
        MainSimulator->setCentralWidget(centralWidget);
        menuBar = new QMenuBar(MainSimulator);
        menuBar->setObjectName(QStringLiteral("menuBar"));
        menuBar->setGeometry(QRect(0, 0, 400, 21));
        menu_File = new QMenu(menuBar);
        menu_File->setObjectName(QStringLiteral("menu_File"));
        menuView = new QMenu(menuBar);
        menuView->setObjectName(QStringLiteral("menuView"));
        menuEdit = new QMenu(menuBar);
        menuEdit->setObjectName(QStringLiteral("menuEdit"));
        menuHelp = new QMenu(menuBar);
        menuHelp->setObjectName(QStringLiteral("menuHelp"));
        MainSimulator->setMenuBar(menuBar);
        mainToolBar = new QToolBar(MainSimulator);
        mainToolBar->setObjectName(QStringLiteral("mainToolBar"));
        MainSimulator->addToolBar(Qt::TopToolBarArea, mainToolBar);
        statusBar = new QStatusBar(MainSimulator);
        statusBar->setObjectName(QStringLiteral("statusBar"));
        MainSimulator->setStatusBar(statusBar);

        menuBar->addAction(menu_File->menuAction());
        menuBar->addAction(menuView->menuAction());
        menuBar->addAction(menuEdit->menuAction());
        menuBar->addAction(menuHelp->menuAction());
        menu_File->addAction(actionNewConfig);
        menu_File->addAction(actionOpenConfig);
        menu_File->addSeparator();
        menu_File->addAction(actionSave);
        menu_File->addAction(actionSaveAs);
        menu_File->addSeparator();
        menu_File->addAction(actionQuit);
        menuView->addAction(actionMeasurement_setup);
        menuEdit->addAction(actionRemove);
        menuEdit->addAction(actionEditView);
        menuHelp->addAction(actionAbout_CAN_Simulator);
        mainToolBar->addSeparator();

        retranslateUi(MainSimulator);

        QMetaObject::connectSlotsByName(MainSimulator);
    } // setupUi

    void retranslateUi(QMainWindow *MainSimulator)
    {
        MainSimulator->setWindowTitle(QApplication::translate("MainSimulator", "MainSimulator", Q_NULLPTR));
        actionNewConfig->setText(QApplication::translate("MainSimulator", "New configuration", Q_NULLPTR));
        actionOpenConfig->setText(QApplication::translate("MainSimulator", "Open configuration", Q_NULLPTR));
        actionSave->setText(QApplication::translate("MainSimulator", "Save", Q_NULLPTR));
        actionSaveAs->setText(QApplication::translate("MainSimulator", "Save as", Q_NULLPTR));
        actionQuit->setText(QApplication::translate("MainSimulator", "Quit", Q_NULLPTR));
        actionMeasurement_setup->setText(QApplication::translate("MainSimulator", "Measurement setup", Q_NULLPTR));
        actionRemove->setText(QApplication::translate("MainSimulator", "Remove", Q_NULLPTR));
        actionEditView->setText(QApplication::translate("MainSimulator", "Edit/View", Q_NULLPTR));
        actionAbout_CAN_Simulator->setText(QApplication::translate("MainSimulator", "About CAN Simulator", Q_NULLPTR));
        menu_File->setTitle(QApplication::translate("MainSimulator", "&File", Q_NULLPTR));
        menuView->setTitle(QApplication::translate("MainSimulator", "View", Q_NULLPTR));
        menuEdit->setTitle(QApplication::translate("MainSimulator", "Edit", Q_NULLPTR));
        menuHelp->setTitle(QApplication::translate("MainSimulator", "Help", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class MainSimulator: public Ui_MainSimulator {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINSIMULATOR_H
