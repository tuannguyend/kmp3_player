#ifndef DIALOGGETID_H
#define DIALOGGETID_H
#include <QDialog>
#include <QLabel>
#include <QLineEdit>
#include <QComboBox>
#include <QStringList>
#include <QPushButton>
class DialogGetID: public QDialog
{
    Q_OBJECT
public:
    explicit  DialogGetID(QWidget *parent=0);
    ~DialogGetID();
private:
   QLabel *LabelEnter;
   QLabel *LabelStartID;
   QLabel *LabelEndID;
   QLabel *LabelSpinbox;
   QLineEdit *LineEditStartID;
   QLineEdit *LineEditEndID;
   QComboBox *ComboBoxBussystem;
   QPushButton *buttonOk;
   QPushButton *buttonCancel;
   QStringList m1_TableHeader;
signals:
void getId(int,int);
public slots:
   void idRange();

};
#endif // DIALOGGETID_H
