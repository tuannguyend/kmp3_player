#ifndef TRACEMANAGER_H
#define TRACEMANAGER_H

#include <QMainWindow>

namespace Ui {
class TraceManager;
}

class TraceManager : public QMainWindow
{
    Q_OBJECT

public:
    explicit TraceManager(QWidget *parent = 0);
    ~TraceManager();
    void setupItems();
private:
    Ui::TraceManager *ui;
};

#endif // TRACEMANAGER_H
