#ifndef MEASURESETUP_H
#define MEASURESETUP_H

#include <QMainWindow>
#include <QToolButton>
#include <QThread>
#include <QDebug>
#include <QCloseEvent>
#include<QJsonDocument>
#include <CANDefines.h>
#include "ui_measuresetup.h"
#include "utilities.h"
class MeasureSetupItemCommon;
class MeasureSetupModel;

typedef enum{
    E_MeasureSetupItemType_None=0,
    E_MeasureSetupItemType_Join,
    E_MeasureSetupItemType_Filter,
    E_MeasureSetupItemType_IG,
    E_MeasureSetupItemType_Interface,
    E_MeasureSetupItemType_Trace
}E_MeasureSetupItemType;

typedef enum{
    E_MeasureSetupBranch_None = 0,
    E_MeasureSetupBranch_IG,
    E_MeasureSetupBranch_Main,
    E_MeasureSetupBranch_View,
}E_MeasureSetupBranch;

typedef enum{
    E_MsgDataID_None=0,
    E_MsgDataID_Timer,
    E_MsgDataID_CANMsgTx,
    E_MsgDataID_CANMsgRx
}E_MsgDataID;

typedef struct MessageCommon{
    E_MsgDataID m_Id;
}MessageCommon;


typedef struct MessageCANTx{
    E_MsgDataID m_Id;
    CANMessageSimulate m_Msg;

}MessageCANTx;

typedef struct MessageCANRx{
    E_MsgDataID m_Id;
    CANMessageSimulate m_Msg;
}MessageCANRx;


class MeasureSetupWindow : public QMainWindow,Ui_MeasureSetup
{
    Q_OBJECT
public:
    explicit MeasureSetupWindow(QWidget *parent = 0 ,MeasureSetupModel * model=0);
    ~MeasureSetupWindow();
    virtual void resizeEvent(QResizeEvent *);
    virtual void paintEvent(QPaintEvent *evt);
    void drawModel();
    void startSimulate();
    void stopSimulate();

protected:
    virtual void closeEvent(QCloseEvent *evt){evt->ignore();}
private:

    void rePaint();
};

class MeasureSetupModel{
public:
    explicit MeasureSetupModel(const QString &path = QString()){
        loadConfig(path);
         m_Running=false;
    }
    ~MeasureSetupModel(){deleteItemsRecursive(m_rootItem); m_rootItem = NULL;}
    MeasureSetupItemCommon *getRootItem(){return m_rootItem;}

private:
    MeasureSetupItemCommon * m_rootItem;
    void deleteItemsRecursive(MeasureSetupItemCommon *item);
    void loadConfig(const QString &configPath);
    bool m_Running;
};

class MeasureSetupWidget: public QToolButton
{
public:
    MeasureSetupWidget(const QIcon& icon,
                       const QString &text,
                       QWidget *parent=0,
                       MeasureSetupItemCommon *pItem=0,
                       E_MeasureSetupItemType mType =E_MeasureSetupItemType_None )
        :QToolButton(parent){
        setIcon(icon);
        setText(text);
        setItemParent(pItem);
       m_WidgetType =  mType ;
    }
    ~MeasureSetupWidget(){}
    void setItemParent(MeasureSetupItemCommon *pItem) {m_Item = pItem;}
protected:
    void mouseReleaseEvent(QMouseEvent *);
private:
    MeasureSetupItemCommon *m_Item;
    E_MeasureSetupItemType m_WidgetType;
};


class MeasureSetupWindowCommon: public QMainWindow
{
public:
    MeasureSetupWindowCommon(QWidget *parent=0, MeasureSetupItemCommon * itemParent=0):QMainWindow(parent){}
    ~MeasureSetupWindowCommon(){}
private:
    MeasureSetupItemCommon * m_ParentItem;
};

class MeasureSetupItemCommon: public QObject
{
    Q_OBJECT
public:
    explicit MeasureSetupItemCommon(MeasureSetupItemCommon *parent = 0,E_MeasureSetupItemType itemType = E_MeasureSetupItemType_None, E_MeasureSetupBranch itemBranch = E_MeasureSetupBranch_None);
    ~MeasureSetupItemCommon();

    void setType(E_MeasureSetupItemType itemType){m_itemType = itemType;}
    E_MeasureSetupItemType getType(){return m_itemType ;}
    E_MeasureSetupBranch getBranch(){return m_itemBranch;}
    MeasureSetupItemCommon * getRootBranch();// get root hops same branch
    MeasureSetupItemCommon *child(int number);
    int childCount() const;
    bool insertChildren(int position,MeasureSetupItemCommon * child);
    bool addChildren(int position, MeasureSetupItemCommon * child);

    MeasureSetupItemCommon *parent();
//    bool removeChildren(int position, int count);
    bool removeChildren(MeasureSetupItemCommon * child);
    int childNumber() const;
    void refreshConnection();
    QJsonValue saveDocument(QJsonArray & parent );
    void cleanWidget(){qDeleteAll(m_widget);}
    void cleanWindow(){if(m_OperateWindow) delete m_OperateWindow;}
signals:
    virtual void sendData(MessageCommon * data);

public slots:
    virtual void rcvData(MessageCommon * data = 0){
        if(processData(data)==true && m_childItems.size()!=0){
            emit sendData(data);
        }else{
            delete data;
        }
    }

private:
    E_MeasureSetupItemType m_itemType;
    E_MeasureSetupBranch m_itemBranch;
    QList<MeasureSetupItemCommon*> m_childItems;
    MeasureSetupItemCommon *m_parentItem;
    QList <MeasureSetupWidget *>m_widget;
    MeasureSetupWindowCommon * m_OperateWindow;
    bool m_JoinActive;
private:
    virtual bool processData(MessageCommon * data = 0){
        return true;
    }

};

class MeasureSetupItemJoin:public MeasureSetupItemCommon
{
    Q_OBJECT
public:
    explicit MeasureSetupItemJoin(MeasureSetupItemCommon *parent = 0);
    ~MeasureSetupItemJoin();
public slots:

private:

};

class MeasureSetupItemFilter:public MeasureSetupItemCommon
{
    Q_OBJECT
public:
    explicit MeasureSetupItemFilter(MeasureSetupItemCommon *parent = 0);
    ~MeasureSetupItemFilter();
public slots:
    //    virtual void rcvData();
private:
};

#endif // MEASURESETUP_H
