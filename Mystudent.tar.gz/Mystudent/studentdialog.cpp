#include "studentdialog.h"
#include "ui_studentdialog.h"
#include "student.h"
#include "canceldialog.h"

StudentDialog::StudentDialog(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::StudentDialog)
{
    ui->setupUi(this);
    setWindowTitle(QString("Information of Student"));
    m_CancelDialog = new CancelDialog;

}

void StudentDialog::Show(Student* student)
{
    ui->namestudents->setText(student->Getname());
    ui->DOBstudent->setText(student->GetDOB());
    ui->classstudents->setText(student->GetClass());

    m_Student = student;
    show();
}

StudentDialog::~StudentDialog()
{
    delete ui;
    delete m_CancelDialog;

}

void StudentDialog::on_pushButton_released()
{
    m_Student->Setname(ui->namestudents->text());
    m_Student->SetDOB(ui->DOBstudent->text());
    m_Student->SetClass(ui->classstudents->text());

    hide();
}

void StudentDialog::on_pushButton_2_clicked()
{
    hide();
}

void StudentDialog::on_pushButton_3_clicked()
{
    m_CancelDialog->show();
}
