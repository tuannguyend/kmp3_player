#include "canceldialog.h"
#include "ui_canceldialog.h"
#include "thanksdialog.h"
#include <QMessageBox>
#include<QCloseEvent>

CancelDialog::CancelDialog(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::CancelDialog)
{
    ui->setupUi(this);
    setWindowTitle(QString("TT of Student"));
    m_ThanksDialog = new ThanksDialog;
}

CancelDialog::~CancelDialog()
{
    delete ui;
    delete m_ThanksDialog;

}

void CancelDialog::on_pushButton_released()
{
    m_ThanksDialog->show();

}

void CancelDialog::closeEvent(QCloseEvent *event){
    if(QMessageBox::question(this, "what is ?", "Tuan")==QMessageBox::No)
    {
        event->ignore();
    }
}
