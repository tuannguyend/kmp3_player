#ifndef THANKSDIALOG_H
#define THANKSDIALOG_H
//#include "test.h"
#include <QDialog>

namespace Ui {
class ThanksDialog;
}
class Testtuan;
class ThanksDialog : public QDialog
{
    Q_OBJECT

public:
    explicit ThanksDialog(QWidget *parent = 0);
    ~ThanksDialog();
protected:
    void closeEvent(QCloseEvent* event);


private slots:
    void on_pushButton_released();

private:
    Ui::ThanksDialog *ui;
   Testtuan* m_TestDialog;
};

#endif // THANKSDIALOG_H
