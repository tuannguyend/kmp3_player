#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include "student.h"
#include <QString>
#include <QVector>

namespace Ui {
class MainWindow;
}
class QListWidgetItem;
class StudentDialog;
class CancelDialog;
class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();

    void AddStudent(Student* student);
    void AddStudent(QString name);
    void AddStudent(QString name, QString DOB, QString Class);

    void RemoveStudent(Student* student);

private slots:
    void on_listWidget_itemDoubleClicked(QListWidgetItem *item);

    void on_sub_clicked();

    void on_add_clicked();

    void on_close_clicked();

    void SaveSetting();
    void LoadSetting();

protected:
    void closeEvent(QCloseEvent* event);

private:
    Ui::MainWindow *ui;
    QVector<Student*> m_Students;

    StudentDialog* m_StudentDialog;
  //  CancelDialog* m_CancelDialog;
};

#endif // MAINWINDOW_H
