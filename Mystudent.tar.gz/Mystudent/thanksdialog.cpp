#include "thanksdialog.h"
#include "ui_thanksdialog.h"
#include <QCloseEvent>
#include<QMessageBox>
#include "test.h"

ThanksDialog::ThanksDialog(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::ThanksDialog)
{
    ui->setupUi(this);
    setWindowTitle(QString ("Test"));
    m_TestDialog = new Testtuan;
}

ThanksDialog::~ThanksDialog()
{
    delete ui;
    delete m_TestDialog;
}
void ThanksDialog::closeEvent(QCloseEvent *event)
{
    if(QMessageBox::question(this,"Confirm","Do you want to exit?")==QMessageBox::No)
    {
            event->ignore();

    }
}



void ThanksDialog::on_pushButton_released()
{
    m_TestDialog.
}
