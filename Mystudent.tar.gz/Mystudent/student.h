#ifndef STUDENT_H
#define STUDENT_H

#include <QListWidgetItem>
#include<QString>
class Student : public QListWidgetItem
{
public:
    Student() {}
    Student(QString name);
    Student (QString name, QString DOB, QString Class);
    ~Student(){}

    void Setname(QString name);
    void SetDOB(QString DOB);
    void SetClass(QString Class);

    QString Getname() const;
    QString GetDOB() const;
    QString GetClass() const;



private:
    QString m_DOB;
    QString m_Class;
};

inline void Student::Setname(QString name)
{
    QListWidgetItem::setText(name);
}


inline void Student::SetDOB(QString DOB)
{
    m_DOB=DOB;
}

inline void Student::SetClass(QString Class)
{
    m_Class=Class;
}

inline QString Student::Getname() const
{
    return QListWidgetItem::text();
}

inline QString Student::GetDOB() const
{
    return m_DOB;
}

inline QString Student::GetClass() const
{
    return m_Class;
}
#endif // STUDENT_H


