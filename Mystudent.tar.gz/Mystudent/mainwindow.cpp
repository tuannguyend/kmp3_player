#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "student.h"
#include <QListWidgetItem>
#include "studentdialog.h"
#include <QString>
#include "canceldialog.h"
#include <QMessageBox>
#include <QCloseEvent>
#include<QSettings>

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    setWindowTitle(QString("Schedule of Student"));
    m_StudentDialog = new StudentDialog;
    LoadSetting();





/*    Student* student = new Student();
    student->Setname("Nguyen Duc Tuan");
    student->SetDOB("26/11/1994");
    student->SetClass("Class: 12DT3");

    ui->listWidget->addItem((QListWidgetItem*) student);
*/
}

void MainWindow::AddStudent(Student *student)
{
    ui->listWidget->addItem((QListWidgetItem*) student);
    m_Students.push_back(student);
}

void MainWindow::AddStudent(QString name)
{
    Student* student = new Student(name);
    AddStudent(student);

}



void MainWindow::AddStudent(QString name, QString DOB, QString Class)
{
    Student* student = new Student(name, DOB, Class);
    AddStudent(student);
}
void MainWindow::RemoveStudent(Student *student)
{
    ui->listWidget->removeItemWidget((QListWidgetItem*) student);

    for(int i=0; i<m_Students.size();++i)
    {
        if(m_Students[i]==student)
        {
             m_Students.remove(i);
            delete student;
        }
    }

}


MainWindow::~MainWindow()
{
    for(int i=0; i<m_Students.size();++i)
    {
        RemoveStudent(m_Students[i]);
    }
    delete ui;
    delete m_StudentDialog;
}


void MainWindow::on_sub_clicked()
{
    RemoveStudent((Student*) ui->listWidget->currentItem());
}

void MainWindow::on_add_clicked()
{
    AddStudent("Tuan handsome");
}

void MainWindow::SaveSetting()
{
    QSettings setting("MyName","MyApp");
    setting.beginGroup("Save Schedule");
    setting.setValue("Schedule", ui->close->isChecked());
    setting.endGroup();
}

void MainWindow::LoadSetting()
{
    QSettings setting("MyName","MyApp");
    setting.beginGroup("Save Schedule");
    ui->close->setChecked(setting.value("Schedule").toBool());
    setting.endGroup();
}

void MainWindow::closeEvent(QCloseEvent *event)
{
    if(QMessageBox::question(this,"Confirm","Do you want to exit?")==QMessageBox::No)
    {       SaveSetting();
            event->ignore();
    }
}

void MainWindow::on_listWidget_itemDoubleClicked(QListWidgetItem *item)
{
    m_StudentDialog->Show((Student*) item);
}

void MainWindow::on_close_clicked()
{
    close();
}
