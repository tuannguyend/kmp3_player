#include "student.h"

Student::Student(QString name)
    : QListWidgetItem(name)
{

}

Student::Student(QString name, QString DOB, QString Class)
    : QListWidgetItem(name),
    m_DOB(DOB),
    m_Class(Class)
{

}

