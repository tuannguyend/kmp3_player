#ifndef CANCELDIALOG_H
#define CANCELDIALOG_H
//#include "thanksdialog.h"
#include <QDialog>

namespace Ui {
class CancelDialog;
}
class ThanksDialog;
class CancelDialog : public QDialog
{
    Q_OBJECT

public:
    explicit CancelDialog(QWidget *parent = 0);
    ~CancelDialog();

protected:
    void closeEvent(QCloseEvent *event);
private slots:
    void on_pushButton_released();

private:
    Ui::CancelDialog *ui;
   ThanksDialog* m_ThanksDialog;
};

#endif // CANCELDIALOG_H
