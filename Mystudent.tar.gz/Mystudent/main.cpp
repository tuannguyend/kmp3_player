#include "mainwindow.h"
#include <QApplication>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    MainWindow w;

    w.AddStudent("Nguyen Duc Tuan", "26/11/1994", "Class:12DT3");
    w.AddStudent("Le Quoc Cong", "14/12/1994", "Class:12X1B");
    w.AddStudent("Cong Be De", "14/12/1994", "Class:12X1B");
    w.AddStudent("Tuan Dep Trai", "26/11/1994", "Class:12DT3");

    w.show();

    return a.exec();
}
