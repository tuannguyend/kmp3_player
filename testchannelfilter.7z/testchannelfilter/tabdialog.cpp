/****************************************************************************
**
** Copyright (C) 2016 The Qt Company Ltd.
** Contact: https://www.qt.io/licensing/
**
** This file is part of the examples of the Qt Toolkit.
**
** $QT_BEGIN_LICENSE:BSD$
** Commercial License Usage
** Licensees holding valid commercial Qt licenses may use this file in
** accordance with the commercial license agreement provided with the
** Software or, alternatively, in accordance with the terms contained in
** a written agreement between you and The Qt Company. For licensing terms
** and conditions see https://www.qt.io/terms-conditions. For further
** information use the contact form at https://www.qt.io/contact-us.
**
** BSD License Usage
** Alternatively, you may use this file under the terms of the BSD license
** as follows:
**
** "Redistribution and use in source and binary forms, with or without
** modification, are permitted provided that the following conditions are
** met:
**   * Redistributions of source code must retain the above copyright
**     notice, this list of conditions and the following disclaimer.
**   * Redistributions in binary form must reproduce the above copyright
**     notice, this list of conditions and the following disclaimer in
**     the documentation and/or other materials provided with the
**     distribution.
**   * Neither the name of The Qt Company Ltd nor the names of its
**     contributors may be used to endorse or promote products derived
**     from this software without specific prior written permission.
**
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
** "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
** LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
** A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
** OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
** DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
** THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
** (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
** OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE."
**
** $QT_END_LICENSE$
**
****************************************************************************/

#include <QtWidgets>

#include "tabdialog.h"
#include <QTableWidget>
#include <QStringList>
//! [0]
TabDialog::TabDialog(const QString &fileName, QWidget *parent)
    : QDialog(parent)
{
 //   QFileInfo fileInfo(fileName);
//   tableWidget = new QTableWidget;
    tabWidget = new QTabWidget;
 buttonPass = new QPushButton(tr("Pass"));
 buttonBlock = new QPushButton(tr("Block"));
 buttonPassAll = new QPushButton(tr("Pass All"));
 buttonBlockAll= new QPushButton(tr("Block All"));
 checkboxChannelName = new QCheckBox(tr("Channel name"));
 buttonOk = new QPushButton(tr("OK"));
 buttonCancel = new QPushButton(tr("Cancel"));
 buttonHelp = new QPushButton(tr("Help"));

//! [0]

//! [1] //! [2]
//    buttonBox = new QDialogButtonBox(QDialogButtonBox::Ok
//                                     | QDialogButtonBox::Cancel
//                                     | QDialogButtonBox::Help);

//    connect(buttonBox, &QDialogButtonBox::accepted, this, &QDialog::accept);
//    connect(buttonBox, &QDialogButtonBox::rejected, this, &QDialog::reject);
//    connect(buttonBox, &QDialogButtonBox::rejected, this, &QDialog::reject);
//    connect(buttonBox, &QDialogButtonBox::rejected, this, &QDialog::reject);

//! [2] //! [3]
//    buttonAdd = new QPushButton(tr("Add"));
//    buttonRemove = new QPushButton(tr("Remove"));
//    buttonView = new QPushButton(tr("View"));
//    QTreeWidget *signal = new QTreeWidget;
//    signal->setColumnCount(2);
//    signal->setHeaderLabels(QStringList() << "Name"<< "Address");

    signal = new QTableWidget(2,2,0);
    m1_TableHeader<<"Channel"<<"Filter"<<"";
    signal->setHorizontalHeaderLabels(m1_TableHeader);
    signal->verticalHeader()->setVisible(false);
    signal->setShowGrid(false);

    QGridLayout *mainLayout = new QGridLayout;
    mainLayout->addWidget(signal,0,0,8,3);

    mainLayout->addWidget(buttonPass,0,3,1,1);
    mainLayout->addWidget(buttonBlock,1,3,1,1);
    mainLayout->addWidget(buttonPassAll,2,3,1,1);
    mainLayout->addWidget(buttonBlockAll,3,3,1,1);
    mainLayout->addWidget(checkboxChannelName,8,3,1,1);
    mainLayout->addWidget(buttonOk,9,1,1,1);
    mainLayout->addWidget(buttonCancel,9,2,1,1);
    mainLayout->addWidget(buttonHelp,9,3,1,1);
    //mainLayout->addStretch(1);
//    mainLayout->addWidget(buttonBox);
    setLayout(mainLayout);

    setWindowTitle(tr("Channel Filter"));
}


