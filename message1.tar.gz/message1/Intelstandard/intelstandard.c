/*
    format Intel_Standard
*/

#include <stdio.h>
#include <string.h>
#include <endian.h>
#include <stdint.h>
#include <stdbool.h>

uint8_t reverse_mask[] =
   {0x55, 0x81, 0xc0, 0xe0, 0xf0, 0xf8, 0xfc, 0xfe, 0xff};
//static const uint8_t reverse_mask_xor[] =
//    { 0xff, 0x7f, 0x3f, 0x1f, 0x0f, 0x07, 0x03, 0x01, 0x00 };
uint8_t testset[8];

typedef union byteArray{
  uint64_t v64;
  unsigned char bytes[8];
}byteArray;
#define CHAR_BIT 8
static uint64_t get_bitfield(const uint8_t source[], const uint8_t source_length,
                const uint16_t offset, const uint16_t bit_count)
{
    printf("source_length: %d\n",source_length);
        printf("offset: %d\n", offset);
        printf("bit_count : %d\n", bit_count);
        printf("GET_bitfield\n");
        printf("-----------\n");
    byteArray value;
    int i=0;
    uint16_t source_length_bits = source_length * CHAR_BIT;
       printf("Source_length_bits: %d\n",source_length_bits);
    //uint16_t new_offset = offset + (64 - source_length_bits);
    printf("check source: \n");
    for(i=0; i<sizeof(reverse_mask); i++) printf("0X%x ",(int) reverse_mask[i]);
    if(source_length > 8 || source_length_bits < (int)((int)offset/8 +1)*8) return 0;
    memset(value.bytes,0,sizeof(byteArray));
    printf("\ncheck value.bytes after memset\n");
    for (i=0;i<8;i++) printf("0x%X ", (int)value.bytes[i]);
    printf("\n");

    memcpy(value.bytes,source,source_length);
    printf("check value.bytes after memcpy\n");
    for (i=0;i<8;i++) printf("0x%X ", (int)value.bytes[i]);
    printf("\n");

    if(BYTE_ORDER == BIG_ENDIAN)
    {
        value.v64 = __builtin_bswap64(value.v64);
        printf("\nValue.v64 after swap:\n");
        for(i=0; i<8; i++) printf("0x%x ", (int) value.bytes[i]);

    }

    for (i=0;i<8;i++) printf("0x%X ", (int)value.bytes[i]);
    printf("\n");
    //if( ((int)((int)new_offset/8 +1)*8 - ((int)bit_count + (int)( (int)new_offset%8))) < 0){
    //	printf("not enough bits\n");
    //	return 0;
    //}

//	value.v64 = value.v64 << (new_offset  - bit_count + (8-new_offset%8));
//	value.v64 = value.v64 >> (new_offset  - bit_count + (8-new_offset%8));
// 	value.v64 = value.v64 >> (64 - (new_offset)   - (8-new_offset%8));
    uint16_t shift_left, shift_right;
    shift_left = 64 - offset - bit_count;
   printf("\nshift_left: %d\n", shift_left);
    shift_right = offset ;
      printf("shift_right: %d\n", shift_right);
    value.v64 = value.v64 << shift_left;
    printf("<< %d\n",shift_left);
    for (i=0;i<8;i++) printf("0x%X ", (int)value.bytes[i]);
    printf("\n");

    value.v64 = value.v64 >> shift_left;
    printf(">> %d\n",shift_left);
    for (i=0;i<8;i++) printf("0x%X ", (int)value.bytes[i]);
    printf("\n");
    value.v64 = value.v64 >> shift_right;
    printf(">> %d\n",shift_right);
    for (i=0;i<8;i++) printf("0x%X ", (int)value.bytes[i]);
    printf("\n");


//	DBG("\n");
    return value.v64;
}



static bool set_bitfield(const uint64_t in_value, const uint16_t offset,
        const uint16_t bit_count, uint8_t destination[],
        uint16_t destination_length)
{       printf("-----------------\n");
       // printf("in_value:\n");
       //     for (int i=0;i<8;i++) printf("0x%X ", in_value[i]);
            printf("\n");
      printf("offset: %d\n", offset);
      printf("bit_count: %d\n", bit_count);
      printf("Destination: ");
        for (int i=0;i<sizeof(testset);i++) printf("0x%X ", (int)destination[i]);

      printf("\nDestination_length: %d\n", destination_length);
      printf("SET_bitfield\n");
      printf("-----------\n");

    bool ret=true;
    int i=0;
    byteArray value;
    byteArray value_new;
    value_new.v64  = in_value;
    printf("\ndang hex: ");
    for (i=0;i<8;i++) printf("0x%X ", (int)value_new.bytes[i]);
    printf("\n");
    uint16_t destination_length_bits = destination_length * CHAR_BIT;
          printf("destination_length_bits %d\n", destination_length_bits);

    if(destination_length > 8) return false;
    if(bit_count > destination_length_bits){printf("\nfalse"); return false;}
    //if((int ) 64 - (int)(new_offset/8 +1)*8  +  (int)(new_offset%8) < 0) return false;
    printf("Check Value_new.bytes \n");
      for ( i=0;i<8;i++) printf("0x%x ", (int)value_new.bytes[i]);
    value_new.v64 <<= 64 - offset - bit_count;
        printf("\nvalue_new.v64 <<=%d\n",64-offset-bit_count);
    for (i=0;i<8;i++) printf("0x%X ", (int)value_new.bytes[i]);
    printf("\n done <<=\n");
    value_new.v64 >>= 64 - offset - bit_count;
          printf("\nvalue_new.v64 >>=%d\n",64-offset-bit_count);
    for (i=0;i<8;i++) printf("0x%X ", (int)value_new.bytes[i]);
    printf("\ndone =>>\n");

        value_new.v64 <<= offset;
              printf("\nvalue_new.v64 >>=%d\n",64-offset-bit_count);
    memset(value.bytes,0,sizeof(byteArray));
        printf("\nCheck Value.bytes after memset \n");
          for ( i=0;i<8;i++) printf("0x%x ", (int)value.bytes[i]);
    memcpy(value.bytes+(8 - destination_length),destination,destination_length);
        printf("\nCheck Value.bytes after memcpy \n");
          for ( i=0;i<8;i++) printf("0x%x ", (int)value.bytes[i]);
    value.v64 |= value_new.v64;
        printf("\n");
    for (i=0;i<8;i++) printf("0x%X ", (int)value.bytes[i]);
    printf("\n");
    if(BYTE_ORDER == BIG_ENDIAN)
    {
        value.v64 = __builtin_bswap64(value.v64);
        printf("\nValue.v64 after swap: \n");
          for (i=0;i<8;i++) printf("0x%x ", (int)value.bytes[i]);
    }
    printf("After swap 2\n");
    for (i=0;i<8;i++) printf("0x%X ", (int)value.bytes[i]);
    printf("\ndone final\n");
    memcpy(destination,value.bytes,destination_length);
         printf("\nCheck Destination after memcpy \n");
    for (i=0;i<8;i++) printf("0x%X ", (int)destination[i]);

    printf("\n");
    return ret;
}

/*inline double CANIntelGetFloat(const uint8_t source[], const uint8_t source_length,
        const uint16_t start_bit_position, const uint16_t bit_count,
        double factor,
        double offset
        )
{
    return (double)get_bitfield(source,source_length,start_bit_position,bit_count) * factor + offset;
}

inline bool CANIntelGetBool(const uint8_t source[], const uint8_t source_length,
        const uint16_t start_bit_position, const uint16_t bit_count
        )
{
    return (bool) (get_bitfield(source,source_length,start_bit_position,bit_count) == 1);
}


inline double CANIntelSetFloat(double in_value,uint8_t destination[], const uint8_t destination_length,
        const uint16_t start_bit_position, const uint16_t bit_count,
        double factor,
        double offset
        )0xFF 0x3
{
//	return (float)set_bitfield(source,source_length,start_bit_position,bit_count);
    if(set_bitfield((uint64_t)((in_value-offset)/factor),start_bit_position,bit_count,destination,destination_length) == true){
        return in_value;
    }
    return -1;
}
inline bool CANIntelSetBool(bool in_value,uint8_t destination[], const uint8_t destination_length,   const uint16_t start_bit_position    )
{0xFF 0x3
    if(set_bitfield((uint64_t)(in_value == true),start_bit_position,1,destination,destination_length) == true){
        return true;
    }
    return false;
}
*/
