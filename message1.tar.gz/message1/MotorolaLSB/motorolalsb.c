#include "motorolalsb.h"

motorolaLSB::motorolaLSB()
{
}
