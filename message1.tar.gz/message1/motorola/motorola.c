/*
 * CANMotorola.c
 *
 *  Created on: Nov 28, 2014
 *      Author: nvthanh
 */


//#include "motorola.h"
//#include <common/Debug.h>
#include <stdio.h>
#include <string.h>
#include <endian.h>
#include <stdint.h>
#include <stdbool.h>


static uint8_t reverse_mask[] =
{ 0x55, 0x80, 0xc0, 0xe0, 0xf0, 0xf8, 0xfc, 0xfe, 0xff };
//static const uint8_t reverse_mask_xor[] =
//    { 0xff, 0x7f, 0x3f, 0x1f, 0x0f, 0x07, 0x03, 0x01, 0x00 };

uint8_t testset[2];
typedef union byteArray{
  uint64_t v64;
  unsigned char bytes[8];
}byteArray;

#define CHAR_BIT 8
static uint64_t get_bitfield(const uint8_t source[], const uint8_t source_length,
                const uint16_t offset, const uint16_t bit_count)
{   printf("source_length: %d\n",source_length);
    printf("offset: %d\n", offset);
    printf("bit_count : %d\n", bit_count);
    printf("GET_bitfield\n");
    printf("-----------\n");
    byteArray value;
    int i=0;
    uint16_t source_length_bits = source_length * CHAR_BIT;
    printf("Source_length_bits: %d\n",source_length_bits);
    uint16_t new_offset = offset + (64 - source_length_bits);
    printf("New_offset: %d\n",new_offset);

    if(source_length > 8 || source_length_bits < (int)((int)offset/8 +1)*8) return 0;
    //Xet hoan toan 1 vung nho byteArray tu vi tri value.bytes tro den = 0
    memset(value.bytes,0,sizeof(byteArray));
    printf("value.v64 after memset:\n");
    for (i=0;i<8;i++) printf("0x%x ", (int)value.bytes[i]);
    //copy source_length byte tu vi tri source tro den vi tri value.bytes+(8-source_length) tro toi
    memcpy(value.bytes+(8 - source_length),source,source_length);
    printf("\ncheck value.v64 after memcpy\n");
     for (i=0;i<8;i++) printf("0x%x ", (int)value.bytes[i]);
     printf("\n------------\n");
    if(BYTE_ORDER == LITTLE_ENDIAN)
    {
    //Tra ve value.v64 voi thu tu bryte bi dao nguoc
        printf("Value.v64 before swap: \n");
          for (i=0;i<8;i++) printf("0x%x ", (int)value.bytes[i]);
        value.v64 = __builtin_bswap64(value.v64);
          printf("\nValue.v64 after swap:\n");
          for(i=0; i<8; i++) printf("0x%x ", (int) value.bytes[i]);

    }
    if( ((int)((int)new_offset/8 +1)*8 - ((int)bit_count + (int)( (int)new_offset%8))) < 0){
        printf("not enough bits\n");
        return 0;
    }

//  value.v64 = value.v64 << (new_offset  - bit_count + (8-new_offset%8));
//	value.v64 = value.v64 >> (new_offset  - bit_count + (8-new_offset%8));
// 	value.v64 = value.v64 >> (64 - (new_offset)   - (8-new_offset%8));
    uint16_t shift_left, shift_right;
    shift_left = ((new_offset/8 +1)*8 - (bit_count + ( new_offset%8)));
    printf("\nshift_left: %d\n", shift_left);
    shift_right =  64 - shift_left - bit_count;
    printf("shift_right: %d\n", shift_right);
    for (i=0;i<8;i++) printf("0x%X ", (int)value.bytes[i]);
    printf("\n");

    value.v64 = value.v64 << shift_left;
    printf("<< %d\n",shift_left);
    for (i=0;i<8;i++) printf("0x%X ", (int)value.bytes[i]);
    printf("\n");

    value.v64 = value.v64 >> shift_left;
    printf(">>%d\n",shift_left);
    for (i=0;i<8;i++) printf("0x%X ", (int)value.bytes[i]);
    printf("\n");
    value.v64 = value.v64 >> shift_right;
    printf(">> %d\n",shift_right);
    for (i=0;i<8;i++) printf("0x%X ", (int)value.bytes[i]);
    printf("\n");
//	DBG("\n");
    return value.v64;
}

/*
 static bool set_bitfield(const uint64_t in_value, const uint16_t offset,
        const uint16_t bit_count, uint8_t destination[],
        uint16_t destination_length)
{      printf("-----------------\n");
       printf("in_value: %d\n", sizeof(in_value));
         printf("offset: %d\n", offset);
         printf("bit_count: %d\n", bit_count);
         printf("Destination: ");
           for (int i=0;i<8;i++) printf("0x%X ", (int)destination[i]);

         printf("\nDestination_length: %d\n", destination_length);
         printf("SET_bitfield\n");
         printf("-----------\n");
    bool ret=true;
    byteArray value;
    byteArray value_new ;
    value_new.v64  = in_value;

    int i=0;
    uint16_t destination_length_bits = destination_length * CHAR_BIT;
    printf("destination_length_bits %d\n", destination_length_bits);
    uint16_t new_offset = offset + (64 - destination_length_bits);
    printf("New_offset:%d\n",new_offset);
//	uint16_t shift_left, shift_right, left_pos, right_pos;
    if(destination_length > 8) return false;
    if(bit_count > destination_length_bits) return false;
    if((int ) 64 - (int)(new_offset/8 +1)*8  +  (int)(new_offset%8) < 0) return false;
    //Dich trai toan hang trai sang so,y,g vi tri la gia tri toan hang phai
    printf("Check Value_new.bytes \n");
      for ( i=0;i<8;i++) printf("0x%x ", (int)value_new.bytes[i]);

    value_new.v64 <<= 64 - bit_count;
    printf("\nvalue_new.v64 <<=%d\n",64-bit_count);
         for ( i=0;i<8;i++) printf("0x%x ", (int)value_new.bytes[i]);
    //Dich phai t0xff 0x80 0xc0 0xe0 0xf0 0xf8 0xfc 0xfe oan hang trai sang so vi tri la gia tri toan hang phai
    value_new.v64 >>= 64 - bit_count;
    printf("\nvalue_new.v64 >>=%d\n",64-bit_count);
        for ( i=0;i<8;i++) printf("0x%x ", (int)value_new.bytes[i]);
    value_new.v64 <<= 64 - (new_offset/8 +1)*8  +  ( new_offset%8);
    printf("\nvalue_new.v64 <<=%d\n",64 - (new_offset/8 +1)*8  +  ( new_offset%8));
        for ( i=0;i<8;i++) printf("0x%x ", (int)value_new.bytes[i]);
    memset(value.bytes,0,sizeof(byteArray));
    printf("\nCheck Value.bytes after memset \n");
      for ( i=0;i<8;i++) printf("0x%x ", (int)value.bytes[i]);
    memcpy(value.bytes+(8 - destination_length),destination,destination_length);
    printf("\nCheck Value.bytes after memcpy \n");
      for ( i=0;i<8;i++) printf("0x%x ", (int)value.bytes[i]);
    if(BYTE_ORDER == LITTLE_ENDIAN)
    {
    //Tra ve value.v64 voi thu tu byte bi dao nguoc
        printf("\nValue.v64 before swap: \n");
          for (i=0;i<8;i++) printf("0x%x ", (int)value.bytes[i]);
        value.v64 = __builtin_bswap64(value.v64);
        printf("\nValue.v64 after swap: \n");
          for (i=0;i<8;i++) printf("0x%x ", (int)value.bytes[i]);
    }
    //OR
    value.v64 |= value_new.v64;
    if(BYTE_ORDER == LITTLE_ENDIAN)
    {
    //Tra ve value.v64 voi thu tu byte bi dao nguoc
        printf("\nValue.v64 before swap: \n");
          for (i=0;i<8;i++) printf("0x%x ", (int)value.bytes[i]);
        value.v64 = __builtin_bswap64(value.v64);
        printf("\nValue.v64 after swap: \n");
          for (i=0;i<8;i++) printf("0x%x ", (int)value.bytes[i]);
    }

    memcpy(destination,value.bytes+(8 - destination_length),destination_length);
    printf("\nCheck Destination after memcpy \n");
      for ( i=0;i<8;i++) printf("0x%x ", (int)destination[i]);
    printf("\n");

    return ret;
}

/*inline double CANMotorolaGetFloat(const uint8_t source[], const uint8_t source_length,
        const uint16_t start_bit_position, const uint16_t bit_count,
        double factor,
        double offset
        )
{
    return (double)get_bitfield(source,source_length,start_bit_position,bit_count) * factor + offset;
}

inline bool CANMotorolaGetBool(const uint8_t source[], const uint8_t source_length,
        const uint16_t start_bit_position, const uint16_t bit_count
        )
{
    return (bool) (get_bitfield(source,source_length,start_bit_position,bit_count) == 1);
}


inline double CANMotorolaSetFloat(double in_value,uint8_t destination[], const uint8_t destination_length,
        const uint16_t start_bit_position, const uint16_t bit_count,
        double factor,
        double offset
        )
{
//	return (float)set_bitfield(source,source_length,start_bit_position,bit_count);
    if(set_bitfield((uint64_t)((in_value-offset)/factor),start_bit_position,bit_count,destination,destination_length) == true){
        return in_value;
    }
    return -1;
}
inline bool CANMotorolaSetBool(bool in_value,uint8_t destination[], const uint8_t destination_length,   const uint16_t start_bit_position    )
{
    if(set_bitfield((uint64_t)(in_value == true),start_bit_position,1,destination,destination_length) == true){
        return true;
    }
    return false;
}*/

